Release for 11/19/2006:
***********************

Usage Notes
===========

Before you attempt to build the PhidgetsDrivers.pbpxml project file in Visual Studio 2005,
it is recommended that you obtain the most current Phidgets binaries for your target platform
and copy them to the target directory, located at .\PhidgetsDrivers\target\%_CPUINDPATH%\ under 
the directory containing your OSDesigns files.  

The Phidget binaries can be obtained at: 
http://www.codeplex.com/Wiki/View.aspx?ProjectName=PhidgetsWinCEDriver and
http://www.phidgets.com/modules.php?op=modload&name=Downloads&file=index&req=getit&lid=30

The link on the Phidgets website may contain a more current version, so it is recommended that
this link be used over the one available on the CodePlex site.  The CodePlex site, however, 
is the best resource for comments and questions.

The release binaries current as of 11/19/2006 for x86 and ARM CPU's are included in this release.

Adding This Project to the OSDesign
===================================

To include the Phidgets Drivers in the OSDesign solution, select the "Project | Add Existing Subproject"
and select the file "PhidgetsDrivers.pbpxml" in the project directory.  You may then right click 
on the PhidgetsDrivers project file under Subprojects folder in the Solution Explorer window, to rebuild 
the OSDesign. This will cause the PhidgetsDrivers and registry entry to be included in the OS image 
file NK.BIN.

For comments or questions regarding these project files, refer to:
www.learningce.com 

For comments or questions regarding the Phidgets drivers, refer to:
www.phidgets.com

