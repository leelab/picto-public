#define DMA_DIRECTION 0  //in=0, out=1
#define DMA_XFER_WIDTH 2 //8-bit=1, 16-bit=2, 32-bit = 3

class dmaChannel
{
public:
	dmaChannel(HANDLE hDAQ);
	~dmaChannel();

	bool reset();
	bool config(int size);
	bool start();
	bool stop();
	bool read();

	typedef enum 
	{
		kNormal = 0,
		kRing,
		kLinkChain,
		kLinkChainRing,
		kNone
	} tDMAMode;


private:
	typedef enum
    {
        kUnknown, 
        kIdle, 
        kConfigured, 
        kStarted,
        kStopped
    } tDMAState;

	int _readIdx;
	int _writeIdx;

	int _size;

	tDMAState		_state;
	tDMAMode		_mode;

	HANDLE			_hDAQ;
};