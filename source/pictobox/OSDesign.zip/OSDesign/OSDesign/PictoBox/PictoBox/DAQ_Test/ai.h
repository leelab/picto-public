#define CONVERT_OUTPUT_SELECT 3

void configureTimebase(HANDLE hDAQ);
void pllReset(HANDLE hDAQ);
void analogTriggerReset(HANDLE hDAQ);
void aiReset(HANDLE hDAQ);
void aiPersonalize(HANDLE hDAQ);
void aiClearFifo(HANDLE hDAQ);
void aiDisarm(HANDLE hDAQ);
void aiClearConfigurationMemory(HANDLE hDAQ);
void aiConfigureChannel(HANDLE hDAQ, ULONG channel, ULONG gain, ULONG polarity, ULONG channelType, BOOL lastChannel);
void aiSetFifoRequestMode(HANDLE hDAQ);
void aiEnvironmentalize(HANDLE hDAQ);
void aiHardwareGating(HANDLE hDAQ);
void aiTrigger(HANDLE hDAQ);
void aiSampleStop(HANDLE hDAQ, int numChannels);
void aiNumberOfSamples(HANDLE hDAQ, int numPreTrigger, int numPostTrigger, bool continuous);
void aiSampleStart(HANDLE hDAQ, int numChannels, int periodDivisor, int delayDivisor, int source);
void aiConvert(HANDLE hDAQ, int convertDelay);
void aiArm(HANDLE hDAQ, bool armSI);
void aiStart(HANDLE hDAQ);
void aiStartOnDemand(HANDLE hDAQ);

#define kAI_START_SelectPulse 18
#define kAI_START_SelectSI_TC 0







