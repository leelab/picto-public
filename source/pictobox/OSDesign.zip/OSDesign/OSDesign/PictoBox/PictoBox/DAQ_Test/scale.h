#ifndef SCALE_H
#define SCALE_H

typedef struct
{
    ULONG order;
    float c[4]; 
}scalingCoeff;

void getCalibrationValues(HANDLE hDAQ, scalingCoeff *scale);
float aiPolynomialScaler(int raw, const scalingCoeff *scale);
void readEeprom(HANDLE hDAQ, unsigned int offset, UCHAR *pBuffer, unsigned int bufferLength);


#endif