#include "stdafx.h"
#include "dma.h"
#include "ai.h"
#include "registerMap.h"
#include "DAQ_Driver.h"

dmaChannel::dmaChannel(HANDLE hDAQ)
{
	_readIdx = 0;
	_state = kUnknown;
	_hDAQ = hDAQ;
	reset();
}
bool dmaChannel::reset()
{
	DWORD bytesWritten;
	DWORD data;

	if(_state == kStarted)
		stop();

	//switch over to bar0 (MITE registers)
	DeviceIoControl(_hDAQ,IOCTRL_USE_BAR0,NULL,0,NULL,0, NULL, NULL);


	//_miteChannel->ChannelOperation.writeDmaReset(1);
	data = 1<<31;
	SetFilePointer(_hDAQ,REG_CHANNEL_OPERATION,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);


	//_miteChannel->ChannelOperation.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_CHANNEL_OPERATION,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->ChannelControl.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_CHANNEL_CONTROL,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->BaseCount.writeRegister (0);
	data = 0;
	SetFilePointer(_hDAQ,REG_BASE_COUNT,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->TransferCount.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_TRANSFER_COUNT,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->MemoryConfig.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_MEMORY_CONFIG,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->DeviceConfig.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_DEVICE_CONFIG,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);


	//_miteChannel->BaseAddress.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_BASE_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->MemoryAddress.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_MEMORY_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//_miteChannel->DeviceAddress.writeRegister(0);
	data = 0;
	SetFilePointer(_hDAQ,REG_DEVICE_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(_hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

    //I haven't figured out the buffering yet, so this is commented out.
	//At some point we may need to reset the buffer.
	/*if ( _buffer != NULL )
    {
        _buffer->free();
        delete _buffer;
        _buffer = NULL; 
    }*/

    _readIdx  = 0; 
    _writeIdx = 0;
    
    _state     = kIdle; 

	return true;
}

//Assumptions;
//		mode = Normal
//		request source = 0
//		transfer width = set by constant 
//		direction = set by constant
bool dmaChannel::config(int size)
{
    if (_state != kIdle)
        return false;
	
	// 1. Store DMA Channel configuration

	_size      = size; 

	// 2. Allocate DMA buffer

	//_buffer = new tLinearDMABuffer ( _bus );
	//^^^^ Doesn't really do anything

	//if (_buffer == NULL)
		//return kSpaceNotAvailable; 

	//if ( _buffer->allocate(_size) < kStatusSuccess )
	//^^^^ calls allocDMA (which is located in some random file in the WDM examples)
	//{
		//delete _buffer; 
		//_buffer = NULL; 
		//return kSpaceNotAvailable;
	//}



	return false;
}

bool dmaChannel::stop()
{
	return false;
}

void allocDMA(int size)
{
   //
   // Allocate DMA'able memory in the kernel
   //
   
   //DeviceIoControl (specific->device, IOCTL_NIRLP_DMA_MEMORY_ALLOC,
   //                           &size, sizeof (u32),
   //                           &physicalAddress, sizeof (LARGE_INTEGER),
   //                           &bytes, NULL);
   
   //
   // Map the buffer to user mode
   //

   ULONGLONG mappedAddress64bit;
   void *mappedAddress; 
   
   //DeviceIoControl (specific->device, IOCTL_NIRLP_DMA_MEMORY_MAP,
   //                           &physicalAddress, sizeof (LARGE_INTEGER),
   //                           &mappedAddress64bit, sizeof (ULONGLONG),
   //                           &bytes, NULL);
   
   mappedAddress = (void*)mappedAddress64bit; 


}