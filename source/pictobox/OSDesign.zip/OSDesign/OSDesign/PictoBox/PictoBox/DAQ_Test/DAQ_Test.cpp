//! A simple test application to confirm that the stream driver is interfacing with the DAQ

/*!
 * This isn't a comprehensive test, but it is useful for verifying that the stream
 * driver is up and running, and talking to the DAQ board.  By defining constants,
 * you can test different parts of the DAQ. 
 */

#include "StdAfx.h"
#include "DAQ_Driver.h"
#include "registerMap.h"
#include "ai.h"
#include "scale.h"
#include "dma.h"

#define AIEX2



void checkStatus(HANDLE);


int _tmain(int argc, TCHAR *argv[], TCHAR *envp[])
{
    _tprintf(_T("Hello World!\n"));

	HANDLE hDAQ;

	DWORD bytesWritten, bytesRead;
	ULONG data;

	hDAQ = CreateFile(L"DAQ1:", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL,0);
	// Check for file open errors
	if (hDAQ == INVALID_HANDLE_VALUE){
		printf("file open errors\n","%X", hDAQ);
		Sleep(4000);
		return 0;
	}

	//************************
	//Check that we are actually writing to the DAQ by writing a value to the scratchpad
	//register at 0x005 (undocumented)
	//************************
	data = 0x12345678;
	SetFilePointer(hDAQ,REG_SCRATCH_PAD,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data, ONE_BYTE, &bytesWritten,NULL);
	data = 0;
	SetFilePointer(hDAQ,REG_SCRATCH_PAD,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&data, ONE_BYTE, &bytesRead,NULL);
	printf("Scratchpad data = 0x%08X\n", data);

	

	//************************
	//Read the EEPROM and get the calibration info
	//************************
	scalingCoeff scale;
	getCalibrationValues(hDAQ,&scale);



	//********************
	//Seek,Read,Write method for DIO
	//********************
	//DWORD data = 0xFFFFFFFF;
	//DWORD bytesWritten,bytesRead;

	//SetFilePointer(hDAQ,0x28,NULL,FILE_BEGIN);
	//WriteFile(hDAQ,&data, 4, &bytesWritten,NULL);

	//data = 0x12341234;

	//SetFilePointer(hDAQ,0x28,NULL,FILE_BEGIN);
	//ReadFile(hDAQ,&data,4,&bytesRead,NULL);
	//printf("Register bar1 + 0x28 = 0x%08X\n", data);

	//
	//data = 0x12345678;
	//SetFilePointer(hDAQ,0x24,NULL,FILE_BEGIN);
	//WriteFile(hDAQ,&data, 4, &bytesWritten,NULL);

	//data = 0x12341234;

	//SetFilePointer(hDAQ,0x24,NULL,FILE_BEGIN);
	//ReadFile(hDAQ,&data,4,&bytesRead,NULL);
	//printf("Register bar1 + 0x24 = 0x%08X\n", data);

	
	
	//*******************************
	// Simple analog input - aiex1.cpp
	//*******************************
	//I'm using the aiex1.cpp file, and trying to replicate what they did
	//The lines of code (many of which are from common.cpp or other included files)
	//are shown in comments, followed by my translation into direct register accesses.
	//
	//The flush command is used to commit changes to the registers.  I am generally 
	//assuming that there is nothing important in the registers before writing to them
	//(a safe assumption since we just booted).  So, I'm not afraid to overwirte 
	//values with zeros.  once we start putting useful stuff in the registers, I will have
	//to be more careful.
	//------------------------------

#ifdef AIEX1
 	int numChannels = 1;
	int numSamples = 10;

	
	// ---- AI Reset ----
	configureTimebase(hDAQ);
	pllReset(hDAQ);
	analogTriggerReset(hDAQ);

	aiReset(hDAQ);
	aiPersonalize(hDAQ);
	aiClearFifo(hDAQ);
	// ---- End of AI Reset ----

	// ---- Start AI task ----

	aiDisarm(hDAQ);

	aiClearConfigurationMemory(hDAQ);


	//Fill configuration FIFO
	for(int channel=0; channel<numChannels; channel++)
	{
		bool lastChannel;
		if(channel == numChannels-1)
			lastChannel = TRUE;
		else
			lastChannel = FALSE;

		aiConfigureChannel(hDAQ,		//HANDLE hDAQ, 
						   channel,		//ULONG channel, 
						   0,			//ULONG gain,			0 = +/- 10V (for a 6221 card)
						   0,			//ULONG polarity,		kAI_Config_PolarityBipolar = 0
						   3,			//ULONG channelType		diff = 1, NRSE = 2, RSE = 3
						   lastChannel);//BOOL lastChannel)
	}

	aiSetFifoRequestMode(hDAQ);

	aiEnvironmentalize (hDAQ);

	aiHardwareGating (hDAQ);
	
	aiTrigger (hDAQ);
	
	aiSampleStop (hDAQ,numChannels);

	aiNumberOfSamples(hDAQ,0,1, true);

	aiSampleStart (hDAQ,numChannels,0,0,kAI_START_SelectPulse);

	aiConvert (hDAQ, 280);

	aiClearFifo(hDAQ);


	aiArm (hDAQ, false);

	aiStart (hDAQ);




	// ---- Read FIFO ----
    
    float value;
    int n = 0; // number of samples counter 
    int m = 0; // number of channels counter
   
   	DeviceIoControl(hDAQ,IOCTRL_USE_BAR1,NULL,0,NULL,0, NULL, NULL);

	while (n < numSamples)
    {
        aiStartOnDemand (hDAQ);

		int scanInProgress = 1;
		do
		{
			//board->Joint_Status_2.readAI_Scan_In_Progress_St()
			SetFilePointer(hDAQ,REG_JOINT_STATUS_2,NULL,FILE_BEGIN);
			ReadFile(hDAQ,&data, TWO_BYTES, &bytesRead,NULL);
			scanInProgress = data & 0x00000080;
			//checkStatus(hDAQ);
		}
		while(scanInProgress);


        
          
        m = 0;
        while ( m < numChannels ) //number of channels
        {
            int FIFOEmpty;
			//board->AI_Status_1.readAI_FIFO_Empty_St()
			SetFilePointer(hDAQ,REG_AI_STATUS_1,NULL,FILE_BEGIN);
			ReadFile(hDAQ,&data, TWO_BYTES, &bytesRead,NULL);
			FIFOEmpty = data & 0x0001000;


			if(!FIFOEmpty)
            {
                //value = board->AI_FIFO_Data.readRegister ();
				SetFilePointer(hDAQ,REG_AI_FIFO_DATA,NULL,FILE_BEGIN);
				ReadFile(hDAQ,&data, FOUR_BYTES, &bytesRead,NULL);
				value = aiPolynomialScaler(data,&scale);
				if(m==0)
					printf ("Sample %d, channel %d: %f\n", n,m,value);
                m++;
            }
			else
			{
				printf("Fifo empty, AI_STATUS_! = 0x%08X\n",data);
				break;
			}
        }
        n++;
    }
    
    // --- Stop ----
	aiDisarm(hDAQ);

#endif	
	

#ifdef AIEX2
	int numChannels = 1;
	int numSamples = 5;
	//int samplePeriodDivisor = 2000; // timebase/sample rate => 20MHz/10kHz
	//int samplePeriodDivisor = 40000; //20MHz/500Hz
	//int samplePeriodDivisor = 4000000; //20MHz/5Hz
	int samplePeriodDivisor = 20000; //20MHz/1kHz
	bool continuous = true;

	//*******************************
	// Hardware timed analog input - aiex2.cpp
	//*******************************
	//I'm using the aiex2.cpp file, and trying to replicate what they did
	//------------------------------
	// ---- AI Reset ----
	configureTimebase(hDAQ);
	pllReset(hDAQ);
	analogTriggerReset(hDAQ);

	aiReset(hDAQ);
	aiPersonalize(hDAQ);
	aiClearFifo(hDAQ);
	// ---- End of AI Reset ----

	// ---- Start AI task ----

	aiDisarm(hDAQ);

	aiClearConfigurationMemory(hDAQ);

	//Fill configuration FIFO
	for(int channel=0; channel<numChannels; channel++)
	{
		bool lastChannel;
		if(channel == numChannels-1)
			lastChannel = TRUE;
		else
			lastChannel = FALSE;

		aiConfigureChannel(hDAQ,		//HANDLE hDAQ, 
						   channel,		//ULONG channel, 
						   0,			//ULONG gain,			0 = +/- 10V (for a 6221 card)
						   0,			//ULONG polarity,		kAI_Config_PolarityBipolar = 0
						   3,			//ULONG channelType		diff = 1, NRSE = 2, RSE = 3
						   lastChannel);//BOOL lastChannel)
	}

	aiSetFifoRequestMode(hDAQ);

	aiEnvironmentalize (hDAQ);

	aiHardwareGating (hDAQ);
	
	aiTrigger (hDAQ);
	
	aiSampleStop (hDAQ,numChannels);

	aiNumberOfSamples(hDAQ,
						0,			//pretrigger smaples
						numSamples,	//posttrigger sample
						continuous);		//continuous?

	aiSampleStart (hDAQ,numChannels,samplePeriodDivisor,3,kAI_START_SelectSI_TC);

	aiConvert (hDAQ, 3);  //3 = convert delay divisor

	aiClearFifo(hDAQ);

	aiArm (hDAQ, true);


	// ---- Read FIFO ----

	float value;
    
    int n = 0;  

	DeviceIoControl(hDAQ,IOCTRL_USE_BAR1,NULL,0,NULL,0, NULL, NULL);

	ULONG dataBuffer[2000];
	DWORD fifoLength = 0;
	LARGE_INTEGER ticksPerMs;
	LARGE_INTEGER startTicks, endTicks;

	QueryPerformanceFrequency(&ticksPerMs);
	ticksPerMs.QuadPart /= 1000;
	
	aiStart (hDAQ);

	Sleep(16);  //16ms = 1 frame = ~16 samples at 1kHz

	//while(1)
	{
		QueryPerformanceCounter(&startTicks);

		DeviceIoControl(hDAQ,IOCTRL_DATA_FIFO_DUMP,NULL,0, dataBuffer, 2000*sizeof(ULONG), &fifoLength, NULL);
		QueryPerformanceCounter(&endTicks);
		fifoLength = fifoLength/sizeof(ULONG);
		printf("\n\n---------------------------------------------------\n\n");

		printf("%d values retrieved\n", fifoLength);
		printf("start ticks: %d\nendticks: %d\n", startTicks.LowPart, endTicks.LowPart);
		printf("Ticks per ms: %d\n",ticksPerMs.QuadPart); 
		printf("%d ms elapsed", (endTicks.QuadPart-startTicks.QuadPart)/ticksPerMs.QuadPart);

		for(int i=0; i<fifoLength; i++)
		{
			value = aiPolynomialScaler(dataBuffer[i],&scale);
			printf ("value %d: %f\t\t%d\n", i,value,dataBuffer[i]);
		}
	}

	/*while (n < numChannels*numSamples+100)
    { 
        int FIFOEmpty;
		
		//board->AI_Status_1.readAI_FIFO_Empty_St()
		SetFilePointer(hDAQ,REG_AI_STATUS_1,NULL,FILE_BEGIN);
		ReadFile(hDAQ,&data, TWO_BYTES, &bytesRead,NULL);
		FIFOEmpty = data & 0x0001000;


		if(!FIFOEmpty)
        {
            //value = board->AI_FIFO_Data.readRegister ();
			SetFilePointer(hDAQ,REG_AI_FIFO_DATA,NULL,FILE_BEGIN);
			ReadFile(hDAQ,&data, FOUR_BYTES, &bytesRead,NULL);
			value = aiPolynomialScaler(data,&scale);
				printf ("value %d: %f\t\t%d\n", n,value,data);
            n++;
        }
		else
		{
			printf("Data fifo is unexpectedly empty\n");
			printf("n = %d\n", n);
			break;
		}
    }*/

	// ---- Stop ----
    
    aiDisarm (hDAQ);

#endif

#ifdef AIEX3
	//*******************************
	// DMA based analog input - aiex3.cpp
	//*******************************

	int numChannels = 1;
	int numSamples = 100000;
	int samplePeriodDivisor = 2000; // timebase/sample rate => 20MHz/10kHz

	const unsigned int dmaSizeInSamples = numSamples;
	const unsigned int dmaSizeInBytes = numSamples*sizeof(USHORT);

	const unsigned int userSizeInSamples = 1000;
	const unsigned int userSizeInBytes = userSizeInSamples*sizeof(USHORT); 

	USHORT rawData[userSizeInSamples];

	dmaChannel *dmaChan;
	dmaChan = new dmaChannel();



		// ---- AI Reset ----
	configureTimebase(hDAQ);
	pllReset(hDAQ);
	analogTriggerReset(hDAQ);

	aiReset(hDAQ);
	aiPersonalize(hDAQ);
	aiClearFifo(hDAQ);
	// ---- End of AI Reset ----

	// ---- Start AI task ----

	aiDisarm(hDAQ);

	aiClearConfigurationMemory(hDAQ);

	//Fill configuration FIFO
	for(int channel=0; channel<numChannels; channel++)
	{
		bool lastChannel;
		if(channel == numChannels-1)
			lastChannel = TRUE;
		else
			lastChannel = FALSE;

		aiConfigureChannel(hDAQ,		//HANDLE hDAQ, 
						   channel,		//ULONG channel, 
						   0,			//ULONG gain,			0 = +/- 10V (for a 6221 card)
						   0,			//ULONG polarity,		kAI_Config_PolarityBipolar = 0
						   3,			//ULONG channelType		diff = 1, NRSE = 2, RSE = 3
						   lastChannel);//BOOL lastChannel)
	}

	aiSetFifoRequestMode(hDAQ);

	aiEnvironmentalize (hDAQ);

	aiHardwareGating (hDAQ);
	
	aiTrigger (hDAQ);
	
	aiSampleStop (hDAQ,numChannels);

	aiNumberOfSamples(hDAQ,
						0,			//pretrigger smaples
						numSamples,	//posttrigger sample
						false);		//continuous?

	aiSampleStart (hDAQ,numChannels,samplePeriodDivisor,3,kAI_START_SelectSI_TC);

	aiConvert (hDAQ, 3);  //3 = convert delay divisor

	aiClearFifo(hDAQ);

	//
    // Configure DMA on the device
    //
    //board->AI_AO_Select.setAI_DMA_Select (1);
	data = 1<<0;
	SetFilePointer(hDAQ,REG_AI_AO_SELECT,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&data, TWO_BYTES, &bytesRead,NULL);

	//dma->config (0, tDMAChannel::kRing, tDMAChannel::kIn, dmaSizeInBytes, tDMAChannel::k16bit);
	dmaChan->config();



#endif


	CloseHandle(hDAQ);

	printf("Goodbye world\n");
	
	return 0;
}



//this function is useful for debugging only
void checkStatus(HANDLE hDAQ)
{
	USHORT aiStatus1,jointStatus1, jointStatus2;
	ULONG data;
	DWORD bytesRead;
	
	SetFilePointer(hDAQ,REG_AI_STATUS_1,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&data, FOUR_BYTES, &bytesRead,NULL);
	aiStatus1 = data;

	SetFilePointer(hDAQ,REG_JOINT_STATUS_1,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&data, FOUR_BYTES, &bytesRead,NULL);
	jointStatus1 = data;

	SetFilePointer(hDAQ,REG_JOINT_STATUS_2,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&data, FOUR_BYTES, &bytesRead,NULL);
	jointStatus2 = data;
	
	printf("AI1=0x%04X ", aiStatus1);
	printf("Joint1=0x%04X ", jointStatus1);
	printf("Joint2=0x%04X\n", jointStatus2);

}