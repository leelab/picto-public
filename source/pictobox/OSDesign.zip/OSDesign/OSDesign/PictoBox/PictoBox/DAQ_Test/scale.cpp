#include "StdAfx.h"
#include "scale.h"
#include "registerMap.h"
#include "DAQ_Driver.h"


//used for converting raw binary to floating point
typedef union {
    UCHAR  b[4];
    float f;
}eepromF32;

float getFloatFromEeprom (const UCHAR eepromMemory[], ULONG offset)
{
    eepromF32 value;
   
	//little endian   
    value.b[3] = eepromMemory[offset++];
    value.b[2] = eepromMemory[offset++];
    value.b[1] = eepromMemory[offset++];
    value.b[0] = eepromMemory[offset++];
   
   
    return value.f;
}

//This function is closely related to the functions in nimseries/Examples/scale.cpp
//However, it is seriosuly limited and designed to work only with 0 gain (+/- 10V).
void getCalibrationValues(HANDLE hDAQ, scalingCoeff *scale)
{
	ULONG eepromInfo[2];
	UCHAR eepromData[1024];

	ULONG calOffset, modeOffset, intervalMemOffset;

	ULONG modeOrder;
	float modeC[4];

	float intervalGain, intervalOffset;


	//The calibration info is stored in the Eeprom from 0x400 to 0x800
	//To make life easier, we'll just read the whole block of memory into
	//an array and work with it there (since IOControls are expensive)
	eepromInfo[0] = 0x400;	//offset
	eepromInfo[1] = 0x400;	//buffer length
	//DeviceIoControl(hDAQ,IOCTRL_READ_EEPROM,eepromInfo,8,eepromData,0x400, &bytesRead, NULL);
	readEeprom(hDAQ,
			   0x400,		//offset
			   eepromData,	//buffer
			   0x400);		//buffer length

	//next, we need to find the area in which the calibration constants are stored
	calOffset = (eepromData[24] << 8) | eepromData[25];
	
	//Now grab all the useful data from the EEPROM
	
	//u32 modeOffset = calOffset + kAiModeBlockStart + (modeIdx*kAiModeBlockSize);
	modeOffset = calOffset + 16 + (0*17);

	modeOrder = eepromData[modeOffset++];
	for(int i=0; i<4; i++)
	{
		modeC[i] = getFloatFromEeprom (eepromData, modeOffset);
		modeOffset+=4;
	}

	//u32 intervalOffset = calOffset + kAiIntervalBlockStart + (intervalIdx*kAiIntervalBlockSize);
	intervalMemOffset = calOffset + 84 + (0*8);
	intervalGain = getFloatFromEeprom (eepromData, intervalMemOffset);
	intervalMemOffset += 4;
	intervalOffset = getFloatFromEeprom (eepromData, intervalMemOffset);

	//Finally, we can store the data collected from the EEPROM
	//in the scaling structure
	scale->order = modeOrder;

	for(int i=0; i<modeOrder; i++)
	{
		scale->c[i] = modeC[i] * intervalGain;
		if(i==0)
			scale->c[i] += intervalOffset;
	}




}

//This function is used to perfom the actual scaling.  You should
//have called getCalibrationValues before using this.
float aiPolynomialScaler(int raw, const scalingCoeff *scale)
{
	float scaledVal;
	ULONG order;

	order = scale->order;
	scaledVal = scale->c[order];

	for(int i=order-1; i>=0; i--)
	{
		scaledVal *= (float)raw;
		scaledVal += scale->c[i];
	}

	return scaledVal;
}

void readEeprom(HANDLE hDAQ, unsigned int offset, UCHAR *pBuffer, unsigned int bufferLen)
{
	ULONG iowcr1Initial;
    ULONG iowbsr1Initial;
    ULONG iodwbsrInitial; 
    ULONG bar1Value;

	DWORD bytesRead, bytesWritten;
	DWORD data;


	
	//switch over to bar0 (MITE registers)
	DeviceIoControl(hDAQ,IOCTRL_USE_BAR0,NULL,0,NULL,0, NULL, NULL);

	//set up the eeprom for reading
	//-----------------------------
	SetFilePointer(hDAQ,REG_IO_DEVICE_BASE_ADDRESS,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&iodwbsrInitial, FOUR_BYTES, &bytesRead,NULL); 

	data = 0;
	SetFilePointer(hDAQ,REG_IO_DEVICE_BASE_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	SetFilePointer(hDAQ,REG_IO_WINDOW_BASE_ADDRESS,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&iowbsr1Initial, FOUR_BYTES, &bytesRead,NULL); 

	SetFilePointer(hDAQ,REG_BASE_ADDRESS_REGISTER_1,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&bar1Value, FOUR_BYTES, &bytesRead,NULL);

	data = 0x0000008B | bar1Value;
	SetFilePointer(hDAQ,REG_IO_WINDOW_BASE_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	SetFilePointer(hDAQ,REG_IO_WINDOW_CONTROL_1,NULL,FILE_BEGIN);
	ReadFile(hDAQ,&iowcr1Initial, FOUR_BYTES, &bytesRead,NULL); 


	data = 0x00000001 | iowcr1Initial;
	SetFilePointer(hDAQ,REG_IO_WINDOW_CONTROL_1,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	data = 0xF;
	SetFilePointer(hDAQ,REG_IO_WINDOW_CONTROL_1,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//Read from the eeprom
	//--------------------
	//Switch to BAR1
	DeviceIoControl(hDAQ,IOCTRL_USE_BAR1,NULL,0,NULL,0, NULL, NULL);
	
	//move to the begining of the desired block of memory
	SetFilePointer(hDAQ,offset,NULL,FILE_BEGIN);

	for(unsigned int i=0; i<bufferLen; i++)
	{
		//*pBufOut=READ_REGISTER_UCHAR((UCHAR*)(pDAQContext->bars[1]+eepromOffset+i));
		//pBufOut++;
		ReadFile(hDAQ,pBuffer,ONE_BYTE,&bytesRead,NULL);
		pBuffer++;
	}

	//switch back to bar0
	DeviceIoControl(hDAQ,IOCTRL_USE_BAR0,NULL,0,NULL,0, NULL, NULL);




	//return the eeprom to its orginal state
	//--------------------------------------
	//WRITE_REGISTER_ULONG((ULONG*)(pDAQContext->bars[0]+ 0xC4), iowbsr1Initial);
	data = iowbsr1Initial;
	SetFilePointer(hDAQ,REG_IO_WINDOW_BASE_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//WRITE_REGISTER_ULONG((ULONG*)(pDAQContext->bars[0]+ 0xC0), iodwbsrInitial);
	data = iodwbsrInitial;
	SetFilePointer(hDAQ,REG_IO_DEVICE_BASE_ADDRESS,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//WRITE_REGISTER_ULONG((ULONG*)(pDAQContext->bars[0]+ 0xF4), iowcr1Initial);
	data = iowcr1Initial;
	SetFilePointer(hDAQ,REG_IO_WINDOW_CONTROL_1,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//WRITE_REGISTER_ULONG((ULONG*)(pDAQContext->bars[0]+ 0x30), 0x00);
	data = 0x00;
	SetFilePointer(hDAQ,REG_ADDRESS_MODE,NULL,FILE_BEGIN);
	WriteFile(hDAQ,&data,FOUR_BYTES,&bytesWritten,NULL);

	//Since most of the time, we'll be reading/writing BAR1, let's
	//leave the dAQ in that state.
	DeviceIoControl(hDAQ,IOCTRL_USE_BAR1,NULL,0,NULL,0, NULL, NULL);




}
