//Matthew Gay
//August 21, 2009
//Yale School of Medicine
//Dept of Neurobiology
//Lee Lab

//! Stream Interface for reading and writing registers on an M-Series data acquisition board.
/*!
 * All interfacing with the DAQ hardware is done through this stream interface.  This interface allows
 * the user to read and write registers from both BARs (Base Adress Registers), as well as to "dump"
 * the contents of the Data Fifo. The interface behaves as you would expect a stream interface to behave.
 *
 * As an example, if the user wanted to write the value 0x1234 to a 2 byte register at adress
 * 0x100 of BAR2, the following code would work:
 * \code
 * HANDLE hDAQ;
 * DWORD bytesWritten, bytesRead;
 * ULONG data;
 *
 * HANDLE hDAQ = CreateFile(_T("DAQ1:"), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL,0);
 * DeviceIoControl(hDAQ,IOCTRL_USE_BAR1,NULL,0,NULL,0, NULL, NULL);
 * data = 0x1234;
 * SetFilePointer(hDAQ,0x100,NULL,FILE_BEGIN);
 * WriteFile(hDAQ,&data, 2, &bytesWritten,NULL);
 * \endcode
 *
 * \sa The DaqBoard class.
 */


#include "stdafx.h"
#include "DAQ_Driver.h"
#include <windows.h>

#include <ceddk.h>
#include <ddkreg.h>
// Also need to include CEDDK.lib in link (see sources file)
// add $(_SYSGENOAKROOT)\lib\$(_CPUINDPATH)\ceddk.lib
// to TARGETLIBS entries
// Declare the Standard External Stream Driver Functions

__declspec(dllexport) extern DWORD DAQ_Init(LPCTSTR pContext, LPCVOID lpvBusContext);
__declspec(dllexport) extern BOOL DAQ_Deinit( DWORD hDeviceContext );
__declspec(dllexport) extern DWORD DAQ_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode );
__declspec(dllexport) extern BOOL DAQ_Close( DWORD hOpenContext );
__declspec(dllexport) extern BOOL DAQ_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut );
__declspec(dllexport) extern void DAQ_PowerUp( DWORD hDeviceContext );
__declspec(dllexport) extern void DAQ_PowerDown( DWORD hDeviceContext );
__declspec(dllexport) extern DWORD DAQ_Read( DWORD hOpenContext, PUCHAR pBuffer, ULONG Count );
__declspec(dllexport) extern DWORD DAQ_Write( DWORD hOpenContext, PUCHAR pBuffer, ULONG Count );
__declspec(dllexport) extern DWORD DAQ_Seek( DWORD hOpenContext, long Amount, WORD Type );

void DBGOut(DWORD dwValue);
void DBGOutHex(DWORD dwValue);

//! Information about the state of the driver/hardware.
typedef struct daq_context_st
{
	DWORD instance;							/*< PCI Instance*/
	DDKPCIINFO PciInfo;						/*< PCI Info Structure from Windows CE DDK */
	DDKWINDOWINFO windowInfo;				/*< PCI Window Info Structure from Windows CE DDK */
	PHYSICAL_ADDRESS busAddress[2];			/*< DAQ's Address on the Bus (1 for each BAR) */
	PHYSICAL_ADDRESS translatedAddress[2];	/*< DAQ's physical address (1 for each BAR) */
	PUCHAR bars[2];							/*< DAQ's virtual address (1 for each BAR) */
	PUCHAR currAddress[2];					/*< The current adress within the BAR */
	UCHAR currBar;							/*< The currently referenced BAR */
} DAQ_CONTEXT;

//! Context for the hardware
typedef struct _OPEN_CONTEXT
{
	DAQ_CONTEXT *pHWContext;
} OPEN_CONTEXT;

// ----------------------------------------------------

//! DLL Entry Point - Doesn't actually do anything
BOOL APIENTRY DllMain( HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved )
{
	switch(ul_reason_for_call) {
		case DLL_PROCESS_ATTACH:
			OutputDebugString(L"DAQ_DRIVER - DLL_PROCESS_ATTACH\n");
			break;
		case DLL_PROCESS_DETACH:
			OutputDebugString(L"DAQ_DRIVER - DLL_PROCESS_DETACH\n");
			break;
		case DLL_THREAD_ATTACH:
			OutputDebugString(L"DAQ_DRIVER - DLL_THREAD_ATTACH\n");
			break;
		case DLL_THREAD_DETACH:
			OutputDebugString(L"DAQ_DRIVER - DLL_THREAD_DETACH\n");
			break;
		default:
			break;
	}
	return TRUE;
}

//! Stream Driver Initialization.
/*! 
 * The Initialization routine queries the registry for information 
 *  about the hardware.  It then stores the information in the driver
 *  context, maps the base adress registers to memory, and tells the
 *  PCI controller on the DAQ where the memory is located
 */
DWORD DAQ_Init( LPCTSTR pContext, LPCVOID lpvBusContext)
{
	OutputDebugString(L"DAQ_DRIVER - DAQ_Init - Context: ");
	OutputDebugString(pContext);
	OutputDebugString(L"\n");

	DAQ_CONTEXT *pDAQContext;
	pDAQContext = (DAQ_CONTEXT*)LocalAlloc( LMEM_FIXED, sizeof( DAQ_CONTEXT ));
	if(pDAQContext == NULL)
	{
		RETAILMSG( 1, (TEXT("DAQ_Init failed, unable to allocate driver context\n")));
		return FALSE;
	}
	
	//****************************************
	//Get the registry key for the device
	//*****************************************
	HKEY hKey;
	hKey =  OpenDeviceKey(pContext); 
	DWORD Type = REG_DWORD;
	DWORD Data;
	DWORD DataSize = sizeof(Data);

	if( ERROR_SUCCESS == RegQueryValueEx( hKey, TEXT("DeviceArrayIndex"), NULL, &Type, (LPBYTE)&Data, &DataSize ) )
		pDAQContext->instance = Data;

	//****************************************
	//recover and print the PCI info
	//*****************************************
	DDKPCIINFO PciInfo;
	DWORD err;

	PciInfo.cbSize = sizeof(PciInfo);
	err = DDKReg_GetPciInfo(hKey, &PciInfo);

	if(err == ERROR_SUCCESS)
	{
		pDAQContext->PciInfo = PciInfo;

		//Now we've got the PCIInnfo, let's print it.
		OutputDebugString(L"********");
		OutputDebugString(L"PCI Info");
		OutputDebugString(L"********");

		OutputDebugString(L"Device Number: ");
		DBGOut(PciInfo.dwDeviceNumber);
		OutputDebugString(L"Function Number: ");
		DBGOut(PciInfo.dwFunctionNumber);
		OutputDebugString(L"Instance: ");
		DBGOut(PciInfo.dwInstanceIndex);
	}
	else if(err == ERROR_INVALID_PARAMETER)
	{
		OutputDebugString(L"DDKReg_GetPciInfo ERROR: Invalid Parameter");
	}
	else if(err == ERROR_INVALID_DATA)
	{
		OutputDebugString(L"DDKReg_GetPciInfo ERROR: Invalid Data");
	}
	else
	{
		OutputDebugString(L"DDKReg_GetPciInfo ERROR: some other error code");
		DBGOut(err);
	}

	//****************************************
	//recover and print PCI window info
	//*****************************************
	DDKWINDOWINFO windowInfo;
	DEVICEWINDOW *pDeviceWindow;

	windowInfo.cbSize = sizeof(windowInfo);

	err = DDKReg_GetWindowInfo(hKey, &windowInfo);
	
	if(err == ERROR_SUCCESS)
	{
		pDAQContext->windowInfo = windowInfo;

		//Now we've got the Window Info, let's print it.
		OutputDebugString(L"***********");
		OutputDebugString(L"Window Info");
		OutputDebugString(L"***********");

		OutputDebugString(L"Bus Number: ");
		DBGOut(windowInfo.dwBusNumber);
		OutputDebugString(L"Interface Type: ");
		DBGOut(windowInfo.dwInterfaceType);
		OutputDebugString(L"Number of I/O windows: ");
		DBGOut(windowInfo.dwNumIoWindows);
		for(unsigned int x=0; x<windowInfo.dwNumIoWindows; x++)
		{
			pDeviceWindow = &(windowInfo.ioWindows[x]);
			OutputDebugString(L"I/O Window");
			OutputDebugString(L"-- Window Base Address:");
			DBGOutHex(pDeviceWindow->dwBase);
			OutputDebugString(L"-- Window Length:");
			DBGOutHex(pDeviceWindow->dwLen);
		}
		OutputDebugString(L"Number of memory windows: ");
		DBGOut(windowInfo.dwNumMemWindows);
		for(unsigned int x=0; x<windowInfo.dwNumMemWindows; x++)
		{
			pDeviceWindow = &(windowInfo.memWindows[x]);
			OutputDebugString(L"I/O Window");
			OutputDebugString(L"-- Window Base Address:");
			DBGOutHex(pDeviceWindow->dwBase);
			OutputDebugString(L"-- Window Length:");
			DBGOutHex(pDeviceWindow->dwLen);
		}

	}
	else if(err == ERROR_INVALID_PARAMETER)
	{
		OutputDebugString(L"DDKReg_GetWindowInfo ERROR: Invalid Parameter");
	}
	else if(err == ERROR_INVALID_DATA)
	{
		OutputDebugString(L"ERROR: Invalid Data");
	}
	else
	{
		OutputDebugString(L"DDKReg_GetWindowInfo ERROR: some other error code");
		DBGOut(err);
	}

	//****************************************
	//Map the PCI windows
	//*****************************************

	OutputDebugString(L"***************");
	OutputDebugString(L"Mapping Windows");
	OutputDebugString(L"***************");

	PCI_COMMON_CONFIG pciConfig;
	PCI_SLOT_NUMBER SlotNumber;

    SlotNumber.u.AsULONG = 0;
    SlotNumber.u.bits.DeviceNumber = PciInfo.dwDeviceNumber;
    SlotNumber.u.bits.FunctionNumber = PciInfo.dwFunctionNumber;


	HalGetBusData(PCIConfiguration, windowInfo.dwBusNumber,SlotNumber.u.AsULONG,&pciConfig,sizeof(pciConfig));
	
	ULONG inIoSpace = 0;
	PHYSICAL_ADDRESS busAddress[2],translatedAddress[2];
	
	PUCHAR bars[2];

	for(int x=0; x<2; x++)
	{
		busAddress[x].HighPart = 0;
		busAddress[x].LowPart =windowInfo.memWindows[x].dwBase;

		pDAQContext->busAddress[x].QuadPart = busAddress[x].QuadPart;
	
		if(!HalTranslateBusAddress(PCIBus,windowInfo.dwBusNumber,busAddress[x],&inIoSpace,&translatedAddress[x]))
			return 1;
		pDAQContext->translatedAddress[x].QuadPart = translatedAddress[x].QuadPart;

		if(inIoSpace == 0) //memory space
		{
			OutputDebugString(L"Translate Bus Address found a memory space (This is good.)");
			bars[x] = (PUCHAR) MmMapIoSpace(translatedAddress[x],windowInfo.memWindows[x].dwLen,FALSE);
			pDAQContext->bars[x] = bars[x];
		}
		else if(inIoSpace == 1) //I/O space
		{
			OutputDebugString(L"Translate Bus Address found an I/O space (This is bad.)");
			return 0;
		}
		else //error!
		{
			OutputDebugString(L"Translate Bus Address failed");
			return 0;
		}
	}

	//write the window data value to the MITE (see chapter 4, section 3 of
	//the E-Series register level programming guide for an explanation of this...)
	//This is essential, otherwise the BAR1 registers won't work.
	//*(PDWORD)(bars[0] + 0xC0)= (translatedAddress[1].LowPart & 0xFFFFFF00) | 0x80;
	WRITE_REGISTER_ULONG((ULONG*)(bars[0]+0xc0),(translatedAddress[1].LowPart & 0xFFFFFF00) | 0x80);

	pDAQContext->currAddress[0] = bars[0];
	pDAQContext->currAddress[1] = bars[1];
	pDAQContext->currBar = 1;

	OutputDebugString(L"DDKReg_GetWindowInfo DemoDriver - Exit DAQ_Init\n");
	return (DWORD)pDAQContext;
}

//! Not implemented
BOOL DAQ_Deinit( DWORD hDeviceContext )
{
	OutputDebugString(L"DAQ_DRIVER - DAQ_Deinit\n");
	OutputDebugString(L"DAQ_DRIVER - Exit DAQ_Deinit\n");
	return TRUE;
}

//!This is called on FileOpen("DAQ1",...)
/*! 
 *  Since most of the setup is taken care of during driver initilization,
 *  opening a new DAQ "file" consits of attaching the perviously created hardware
 *  context to the open context, and then setting the current adresses
 *  to the beginning of their respective memory spaces.
 */
DWORD DAQ_Open( DWORD hDeviceContext, DWORD AccessCode, DWORD ShareMode )
{
	OutputDebugString(L"DemoDriver - DAQ_Open\n");
	OutputDebugString(L"hDeviceContext - ");
	DBGOut(hDeviceContext);
	OutputDebugString(L"\n");


	OPEN_CONTEXT *pOpenContext;

	pOpenContext = (OPEN_CONTEXT*)LocalAlloc( LMEM_FIXED, sizeof( OPEN_CONTEXT ));
	if( pOpenContext == NULL )
	{
		OutputDebugString(L"DAQ_Open failed, unable to allocate open context");
		return FALSE;
	}
	pOpenContext->pHWContext = (DAQ_CONTEXT *)hDeviceContext;

	pOpenContext->pHWContext->currAddress[0] = pOpenContext->pHWContext->bars[0];
	pOpenContext->pHWContext->currAddress[1] = pOpenContext->pHWContext->bars[1];
	pOpenContext->pHWContext->currBar = 1;


	OutputDebugString(L"DemoDriver - Exit DAQ_Open\n");
	return (DWORD)pOpenContext;
}

//! Closes the Open Context
BOOL DAQ_Close( DWORD hOpenContext )
{
	OutputDebugString(L"DAQ_DRIVER - DAQ_Close\n");
	OutputDebugString(L"hOpenContext - ");
	DBGOut(hOpenContext);
	OutputDebugString(L"\n");

	//Free the OPEN_CONTEXT memory
	OPEN_CONTEXT *pOpenContext = (OPEN_CONTEXT *)hOpenContext;
	if(pOpenContext)
		LocalFree(pOpenContext);

	// Add Close Function Code Here
	OutputDebugString(L"DAQ_DRIVER - Exit DAQ_Close\n");
	return TRUE;
}

//!Implements the IO control codes
/*!
 *  The following IO control Codes can be used:
 * \param IOCTRL_USE_BAR0 sets BAR0 as the current BAR for reading/writing
 * \param IOCTRL_USE_BAR1 sets BAR1 as the current BAR for reading/writing
 * \param IOCTRL_DATA_FIFO_DUMP dumps the data fifo into the passed in buffer
 *
 * \note This function is never called directly by the user, but is called by DeviceIOControl()
 */
BOOL DAQ_IOControl( DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn, DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut )
{
	//OutputDebugString(L"DAQ_DRIVER - DAQ_IOControl\n");
	//OutputDebugString(L"hOpenContext - ");
	//DBGOut(hOpenContext);
	//OutputDebugString(L"\n");

	OPEN_CONTEXT *pOpenContext = (OPEN_CONTEXT *)hOpenContext;
	DAQ_CONTEXT *pDAQContext = pOpenContext->pHWContext;
	
	ULONG ioctrlErr = 0;
	
	ULONG iowcr1Initial;
    ULONG iowbsr1Initial;
    ULONG iodwbsrInitial; 
    ULONG bar1Value;

	ULONG eepromOffset;
	ULONG eepromBufferSize;

	USHORT fifoEmpty = TRUE;
	ULONG fifoReads = 0;
	ULONG fifoData;


	switch(dwCode)
	{
	case IOCTRL_USE_BAR0:
		pDAQContext->currBar = 0;
		break;
	case IOCTRL_USE_BAR1:
		pDAQContext->currBar = 1;
		break;

	// The reason we have an IO control for dumping the data buffer (as opposed to
	// repeated calls to ReadFile with the FIFO address) is that every call to a stream
	// driver results in context switching.  So, if we can loop through the data FIFO 
	// without having to switch context, the code will execute much faster.
	case IOCTRL_DATA_FIFO_DUMP:
	
		//REG_AI_STATUS_1 = 0x104
		fifoEmpty = READ_REGISTER_USHORT((USHORT*)(pDAQContext->bars[1]+ 0x104));
		fifoEmpty &= 0x1000;

		while(!fifoEmpty && fifoReads * sizeof(ULONG) < dwLenOut)
		{
			//read a fifo entry
			fifoData = READ_REGISTER_ULONG((ULONG*)(pDAQContext->bars[1]+ 0x01C));
			*(ULONG*)pBufOut=fifoData;
			pBufOut += sizeof(ULONG);
			fifoReads++;

			//check to see if the fifo is empty yet
			fifoEmpty = READ_REGISTER_USHORT((USHORT*)(pDAQContext->bars[1]+ 0x104));
			fifoEmpty &= 0x1000;

		}

		*pdwActualOut = fifoReads*sizeof(ULONG);

		break;
	default:
		ioctrlErr=5;
		break;

	}

	// Add IOCTL Function Code Here
	//OutputDebugString(L"DAQ_DRIVER - Exit DAQ_IOControl\n");
	if(ioctrlErr == 0)
		return TRUE;
	else
		return FALSE;
}

//! Not implemented
void DAQ_PowerUp( DWORD hDeviceContext )
{
	OutputDebugString(L"DAQ_DRIVER - DAQ_PowerUp\n");
	OutputDebugString(L"hDeviceContext - ");
	DBGOut(hDeviceContext);
	OutputDebugString(L"\n");

	// Add PowerUP Function Code Here
	OutputDebugString(L"DAQ_DRIVER - Exit DAQ_PowerUp\n");
}

//! Not implemented
void DAQ_PowerDown( DWORD hDeviceContext )
{
	OutputDebugString(L"DAQ_DRIVER - DAQ_PowerDown\n");
	OutputDebugString(L"hDeviceContext - ");
	DBGOut(hDeviceContext);
	OutputDebugString(L"\n");

	// Add PowerDown Function Code Here
	OutputDebugString(L"DAQ_DRIVER - Exit DAQ_PowerDown\n");
}

//! Read from the current address

/*! 
 * Reads 1,2,or 4 bytes from the current BAR address, and then 
 * increments the BAR adress.  The autoincrementing feature is
 * rarely of any use, due to the fact that registers aren't read
 * in sequential order.  A call to FileRead, is almost always
 * preceeded by a call to SetFilePointer.
 *
 * The limitation in the size of the reads, is due to the fact that 
 * DAQ doesn't seem to like it when you only read a single byte from a 4 byte
 * register, so a looping implementation is not possible.
 * \note This function is never called directly by the user, but is called by FileRead()
 */
DWORD DAQ_Read( DWORD hOpenContext, PUCHAR pBuffer, ULONG Count )
{
	//OutputDebugString(L"DAQ_DRIVER - DAQ_Read\n");
	//OutputDebugString(L"hOpenContext - ");
	//DBGOut(hOpenContext);
	//OutputDebugString(L"\n");


	OPEN_CONTEXT *pOpenContext = (OPEN_CONTEXT *)hOpenContext;
	DAQ_CONTEXT *pDAQContext = pOpenContext->pHWContext;

	// Test the pointer.
	//Stole this code from http://bookfire.net/wince/programming-win-ce-2ed/source/html/ch173.htm
	//We may need to use the exception handling stuff, but I'm willing to take a chance...
    if (IsBadReadPtr (pBuffer, Count)) {
        return -1;
    }
	
	
	
	if(Count == 4)
	{
		*((ULONG*)pBuffer) = READ_REGISTER_ULONG((ULONG*)(pDAQContext->currAddress[pDAQContext->currBar]));
		pDAQContext->currAddress[pDAQContext->currBar] += 4;
		return 4;
	}
	else if(Count == 2)
	{
		*((USHORT*)pBuffer) = READ_REGISTER_USHORT((USHORT*)(pDAQContext->currAddress[pDAQContext->currBar]));
		pDAQContext->currAddress[pDAQContext->currBar] += 2;
		return 2;
	}
	else if(Count == 1)
	{
		*pBuffer = READ_REGISTER_UCHAR(pDAQContext->currAddress[pDAQContext->currBar]);
		pDAQContext->currAddress[pDAQContext->currBar]++;
		return 1;
	}
	else
	{
		return -1;
	}
}

//! Write to the current address

/*! 
 * Writes 1,2,or 4 bytes to the current BAR address, and then 
 * increments the BAR adress.  The autoincrementing feature is
 * rarely of any use, due to the fact that registers aren't written
 * in sequential order.  A call to FileWrite, is almost always
 * preceeded by a call to SetFilePointer.
 *
 * The limitation in the size of the writes, is due to the fact that 
 * DAQ doesn't seem to like it when you only write a single byte from a 4 byte
 * register, so a looping implementation is not possible.
 * \note This function is never called directly by the user, but is called by FileWrite()
 */
DWORD DAQ_Write( DWORD hOpenContext, PUCHAR pBuffer, ULONG Count )
{
	//OutputDebugString(L"DAQ_DRIVER - DAQ_Write\n");
	//OutputDebugString(L"hOpenContext - ");
	//DBGOut(hOpenContext);
	//OutputDebugString(L"\n");
	
	OPEN_CONTEXT *pOpenContext = (OPEN_CONTEXT *)hOpenContext;
	DAQ_CONTEXT *pDAQContext = pOpenContext->pHWContext;

	// Test the pointer.
	//Stole this code from http://bookfire.net/wince/programming-win-ce-2ed/source/html/ch173.htm
	//We may need to use the exception handling stuff, but I'm willing to take a chance...
    if (IsBadWritePtr (pBuffer, Count)) {
        return -1;
    }
	
	
	//NOTE: It would appear that some of the registers on the PCI-6221 don't
	//like it when you write to them one byte at a time.  So, we have to write 
	//the whole buffer in a single call
	if(Count == 4)
	{
		WRITE_REGISTER_ULONG((ULONG*)(pDAQContext->currAddress[pDAQContext->currBar]),*((ULONG*)pBuffer));
		pDAQContext->currAddress[pDAQContext->currBar] += 4;
		return 4;
	}
	else if(Count == 2)
	{
		WRITE_REGISTER_USHORT((USHORT*)(pDAQContext->currAddress[pDAQContext->currBar]),*((USHORT*)pBuffer));
		pDAQContext->currAddress[pDAQContext->currBar] += 2;
		return 2;
	}
	else if(Count == 1)
	{
		WRITE_REGISTER_UCHAR(pDAQContext->currAddress[pDAQContext->currBar],*pBuffer);
		pDAQContext->currAddress[pDAQContext->currBar]++;
		return 1;
	}
	else
	{
		return -1;
	}
}

//! Sets the current adress to the passed in value

/*! This is used to move around to different registers in the DAQ.  Bear in mind that
 * both read and write automatically increment the address, so it is almost always a good 
 * idea to set the file pointer before reading or writing.
 * \return -1 if the adress is invalid, or the current adress if it is valid
 * \note The function assumes that each BAR is 0x1000 bytes long (they are)
 * \note This function is never called directly by the user, but is called by SetFilePointer()
 */
DWORD DAQ_Seek( DWORD hOpenContext, long Amount, WORD Type )
{
	//OutputDebugString(L"DAQ_DRIVER - DAQ_Seek\n");
	//OutputDebugString(L"hOpenContext - ");
	//DBGOut(hOpenContext);
	//OutputDebugString(L"\n");

	OPEN_CONTEXT *pOpenContext = (OPEN_CONTEXT *)hOpenContext;
	DAQ_CONTEXT *pDAQContext = pOpenContext->pHWContext;

	int seekErr = 0;


	switch(Type)
	{
	case FILE_BEGIN:
		if(Amount <= 0x1000 && Amount >= 0)
			pDAQContext->currAddress[pDAQContext->currBar] = pDAQContext->bars[pDAQContext->currBar] + Amount;
		else 
			seekErr = -1;
		break;
	case FILE_CURRENT:
		if(pDAQContext->currAddress[pDAQContext->currBar] + Amount <= pDAQContext->bars[pDAQContext->currBar] + 0x1000 &&
			pDAQContext->currAddress[pDAQContext->currBar] + Amount >= pDAQContext->bars[pDAQContext->currBar])
			pDAQContext->currAddress[pDAQContext->currBar] += Amount;
		else
			seekErr = -1;
		break;
	case FILE_END:
		if(pDAQContext->bars[pDAQContext->currBar] + 0x1000 + Amount >= pDAQContext->bars[pDAQContext->currBar] &&
			pDAQContext->bars[pDAQContext->currBar] + 0x1000 + Amount <= pDAQContext->bars[pDAQContext->currBar] + 0x1000)
			pDAQContext->currAddress[pDAQContext->currBar] = pDAQContext->bars[pDAQContext->currBar] + 0x1000 + Amount;
		else
			seekErr = -1;
		break;
	}


	//OutputDebugString(L"DAQ_DRIVER - Exit DAQ_Seek\n");
	if(seekErr == 0)
		return (DWORD)(pDAQContext->currAddress[pDAQContext->currBar]);
	else
		return 0;
}

//! Useful for outputting values to the debug stream
void DBGOut(DWORD dwValue)
{
	TCHAR tcTemp[20];
	wsprintf(tcTemp,L"%ld",dwValue);
	OutputDebugString(tcTemp);
}

//! Useful for outputting values to the debug stream
void DBGOutHex(DWORD dwValue)
{
	TCHAR tcTemp[20];
	wsprintf(tcTemp,L"0x%lX",dwValue);
	OutputDebugString(tcTemp);
}

