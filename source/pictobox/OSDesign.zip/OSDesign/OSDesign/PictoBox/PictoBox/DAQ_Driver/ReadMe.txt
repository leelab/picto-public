////////////////////////////////////////////////////////////////////////

FEATURE NAME:



MANUFACTURER:



CONTACT INFO:



DATE:



VERSION:



SIZE:



DESCRIPTION:



NOTES:



////////////////////////////////////////////////////////////////////////


========================================================================
       DYNAMIC LINK LIBRARY : DAQ_Driver
========================================================================


The Subproject Wizard has created this DAQ_Driver DLL for you.  

This file contains a summary of what you will find in each of the files that
make up your DAQ_Driver application.

DAQ_Driver.pbpxml
    This file contains information at the subproject level and
    is used to build a single subproject for an OS design.
    Other users can share the subproject (.pbpxml) file.

DAQ_Driver.cpp
    This is the main DLL source file.

DAQ_Driver.h
    This file contains your DLL exports.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named DAQ_Driver.pch and a precompiled types file named StdAfx.obj.


/////////////////////////////////////////////////////////////////////////////
Other notes:

The Subproject Wizard uses "TODO:" to indicate parts of the source code you
should add to or customize.


/////////////////////////////////////////////////////////////////////////////
