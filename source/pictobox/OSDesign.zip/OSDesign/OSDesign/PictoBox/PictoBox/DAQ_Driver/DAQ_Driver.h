//Matthew Gay
//August 21, 2009
//Yale School of Medicine
//Dept of Neurobiology
//Lee Lab

#ifndef DAQ_DRIVER_H
#define DAQ_DRIVER_H

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the DAQ_Driver_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// DAQ_Driver_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef DAQ_Driver_EXPORTS
#define DAQ_Driver_API __declspec(dllexport)
#else
#define DAQ_Driver_API __declspec(dllimport)
#endif

// This class is exported from the DAQ_Driver.dll
class DAQ_Driver_API CDAQ_Driver {
public:
    CDAQ_Driver(void);
    // TODO: add your methods here.
};

extern DAQ_Driver_API int nDAQ_Driver;

DAQ_Driver_API int fnDAQ_Driver(void);

//! IO Control Codes
enum{
	IOCTRL_USE_BAR0,
	IOCTRL_USE_BAR1,
	IOCTRL_DATA_FIFO_DUMP
};

#endif

