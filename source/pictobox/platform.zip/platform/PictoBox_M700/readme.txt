             	   VIA VX800 x86 Board Support Package 1.1
               For Windows Embedded CE 6.0 Installation Guide
                             2008/03/06
             Copyright (C) 2003-2008 VIA Technologies, INC.

1. Release note
   The VIA VX800 Board Support Package (BSP) is for Window Embedded CE 6.0
   It facilitates the OEM to quickly come up with a ready-to-run 
   system for building the OS image, evaluating the drivers, and 
   developing applications. VIA BSP extendsthe WinCE built-in CEPC BSP 
   by adding several chip-specific OAL features and support. 
   The OEM may use all the available drivers offered by the CEPC BSP.
   
   VIAVX800 should be applicable to systems based on VIA chip VX800.

2. Revision note
   Features supported in Version 1.1 but different from Version 
   1.0 are described below:
   (1) Update Gigabit Ethernet driver v1.58
   (2) Update HD Audio driver v1.1
   (3) Update Display driver v7.06.32.34   
  
3. Feature
   The BSP supports the following features.

   (1) VT6122 Ethernet Download/Debug Utility
   (2) Extension RAM detection from 28MB to 512MB
   
4. File description
   The package contains files as described below.

   README.TXT        this file
   VIAVX800.MSI        self-installing Windows installer package file
   
5. Preparation prior to installation
   If you have installed VIA's BSP before,  remove it as below.
   In the Platform Builder, select "Manage catalog features.." from
   the "File" menu; remove the VIACEPC.CEC from the imported
   catalog feature files.

6. Prepare a hardware target platform
   The platform must meet the following requirements.
   
   VIA Vx800 BSP
   (1) CPU: C7
   (2) RAM: 128MB minimum  
   (3) Chip: VX800

7. Install VIA VX800 BSP
   
   Install Path:
   The driver must be installed under the ��WINCE600�� folder which installed Windows Embedded CE 6.0
   
   Double-click VIAVX800.MSI that will do all the installation 
   automatically, including copying driver files.
   The target installation catalog menu paths are 
   Catalog\Third Party\BSP\VIA VX800 BSP CEPC:x86,
   

        
8. Create and build a new platform
   (1) On the "File" menu, select "New" and then click "Project".
   (2) Select Platform Builder for CE6.0
   (2) Type project name and path and then click "OK" and click "Next".
   (3) Select "VIA VX800 BSP CEPC:X86"and then click "Next".
   (3) Choose one from the list of available design templates.
       and then click "Next".
   (4) Click "Finish" to create the new platform.

   (5) Optionally, if you need USB Keyboard and Mouse support,
       click the following componet into the workspace (features) window.

      Catalog\Core OS\CEBASE
                         \Core OS Services
                             \USB Host Support
                                 \USB Human Input Device (HID) Class Driver
                                      \USB HID Keyboard and Mouse

       Note:By default, this component is not included in a new created 
            platform. 

   

   

       
   (6) On the "Build OS" menu, click "Sysgen" to build an image.

9. Download the binary image via Ethernet
   

   (1) Type the following command on the target platform to
       download the OS image via Ethernet.

       loadcepc /E:<I/O port>:<IRQ>[:<dotted IP>] EBOOT.BIN

       where <I/O port> and <IRQ> are the I/O Base Address and
       the Interrupt Output Line respectively, as described in
       the previous step.
    
       Note: 
            Use the GEBOOT.BIN to download the image when use VT6122 Giga LAN.
            GEBOOT.BIN is located at \VIAVX800\Src\Bootloader\Eboot\BIN\             
             
   
   (2) Choose "Connectivity Options.." from the Target menu;
       set the Download option to "Ethernet" ,the
       Transport option to "Ethernet" and Debugger option to "KdStub"; 
       press the "Setting" button. If the connection between
       the target platform and the development workstation 
       is successfully established, a new device named 
       "CEPCxxxx" will show up in the Active Devices box. 
       Select that device and click OK to finish.

       Note: This step is necessary only for the first download.
        
   (3) Choose "Attach Device" from the Target menu.

10. Known issues
   
   (1) Not Support HDD Registry Save function (RAM-based Registry Save)
   

        
        
   
  
   

