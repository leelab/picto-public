#include <windows.h>
#include <oal.h>
#include "powersaver_ctl.h"
#include <ceddk.h>
#include <wdm.h>
#include <Winbase.h>
#include "nkintr.h"
#include "pc.h"
#include "timer.h"



extern void SetQueryPeriod(LPDWORD lpPeriod);
extern void SetIdleThresholdHigh(LPDWORD lpThreshold);
extern void SetIdleThresholdLow(LPDWORD lpThreshold);
extern void SetCurrentRatio(LPDWORD lpCurRatio);
extern void GetCurrentRatio(LPDWORD lpCurRatio);
extern void GetDefaultRatio(LPDWORD lpDefRatio);
extern void SetAdjustFrequencyRatioMode(LPDWORD lpMode);
extern void GetVRMType(LPDWORD lpVRMType);
extern void SetAdjustSoftVIDMode(LPDWORD lpMode);
extern void GetCurrentVID(LPDWORD lpCurVID);
extern void SetCurrentVID(LPDWORD lpCurVID);
extern void GetRatioCounter(LPDWORD lpUpDown, LPDWORD lpValue);
extern void SetRatioCounter();
extern void GetAutoVID(LPDWORD lpAutoVID);
extern void SetAutoVID(LPDWORD lpAutoVID);
extern void GetCPUType(LPDWORD lpCPUType);
extern void GetCPUIdelTime(LPDWORD lpCPUIdelTime);
extern void SetSoftVIDFlag(LPDWORD lpFlag);
extern void GetSoftVIDFlag(LPDWORD lpFlag);
extern void SetGPOBaseAddr(LPDWORD lpGPOBase);
extern void SetGPONumber(LPDWORD lpGPONumber);
extern void ChagneCPURatioFlag();
extern void SetCPUMiniRatio(LPDWORD lpMiniRatio);
extern void SetCPUMaxVID(LPDWORD lpMaxVID);
extern void SetCPUMiniVID(LPDWORD lpMiniVID);
extern void GetCPUMaxVID(LPDWORD lpMaxVID);
extern void GetCPUMaxRatio(LPDWORD lpVlg, LPDWORD lpMaxRatio);
extern void GetCPUMinRatio(LPDWORD lpMinRatio);
extern void GetCPUMinVID(LPDWORD lpMinRatio, LPDWORD lpMinVid);
extern DWORD GetSupportVID(DWORD dwBufSize, LPDWORD lpMinVid);
extern void GetCPUBestRatio(LPDWORD lpMinRatio, LPDWORD lpMinVid);


DWORD dwRNGRate = 0;  

BOOL PowSaverOEMIoControl( 
    UINT32 dwIoControlCode,
    PBYTE lpInBuf,
    UINT32 nInBufSize,
    PBYTE lpOutBuf,
    UINT32 nOutBufSize,
    UINT32* lpBytesReturned
    )
{
    BOOL retval = FALSE;
//    DWORD len;
    DEBUGMSG(0, (TEXT("+PowSaverOEMIoControl %X\r\n"), dwIoControlCode));

    switch (dwIoControlCode) {
   
        case IOCTL_HAL_SET_PERIOD:
            SetQueryPeriod((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_SET_IDLE_THRESHOLDHIGH:
            SetIdleThresholdHigh((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_SET_IDLE_THRESHOLDLOW:
            SetIdleThresholdLow((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_GET_CURRENT_RATIO:
            GetCurrentRatio((LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_GET_DEFAULT_RATIO:
            GetDefaultRatio((LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_ADJUST_FREQUENCY_MODE:
            SetAdjustFrequencyRatioMode((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_SET_CURRENT_RATIO:
            SetCurrentRatio((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_ADJUST_SOFTVID_MODE:
            SetAdjustSoftVIDMode((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_GET_CURRENT_VID:
            GetCurrentVID((LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_SET_CURRENT_VID:
            SetCurrentVID((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_GET_RATIO_COUNTER:
            GetRatioCounter((LPDWORD)lpInBuf, (LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_SET_RATIO_COUNTER:
            SetRatioCounter();
            return TRUE;

        case IOCTL_HAL_GET_AUTO_VID:
            GetAutoVID((LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_SET_AUTO_VID:
            SetAutoVID((LPDWORD)lpInBuf);
            return TRUE;

        case IOCTL_HAL_GET_VRM_TYPE:
            GetVRMType((LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_GET_CPU_TYPE:
            GetCPUType((LPDWORD)lpOutBuf);
            return TRUE;

        case IOCTL_HAL_GET_CPU_IdelTime:
            GetCPUIdelTime((LPDWORD)lpOutBuf);
            return TRUE;
        
        case IOCTL_HAL_Set_SOFTVID_FLAG:
            SetSoftVIDFlag((LPDWORD)lpInBuf);
            return TRUE;
        
        case IOCTL_HAL_Get_SOFTVID_FLAG:
            GetSoftVIDFlag((LPDWORD)lpOutBuf);
            return TRUE;
        
        case IOCTL_HAL_SET_GPO_BASEADDR:
            SetGPOBaseAddr((LPDWORD)lpInBuf);
            return TRUE;
        
        case IOCTL_HAL_SET_GPO_NUMBER:
            SetGPONumber((LPDWORD)lpInBuf);
            return TRUE;
        
        case IOCTL_HAL_SET_CPU_MINIRATIO:
            SetCPUMiniRatio((LPDWORD)lpInBuf);
            return TRUE;
       
        case IOCTL_HAL_SET_CPU_MAXVID:
            SetCPUMaxVID((LPDWORD)lpInBuf);
            return TRUE;
        
        case IOCTL_HAL_SET_CPU_MINIVID:
            SetCPUMiniVID((LPDWORD)lpInBuf);
            return TRUE;
        
        case IOCTL_HAL_CHANGE_CPURTAIO_FLAG:
            ChagneCPURatioFlag((LPDWORD)lpInBuf);
            return TRUE;
            
        case IOCTL_HAL_GET_CPU_MAXRATIO:
            GetCPUMaxRatio((LPDWORD)lpInBuf, (LPDWORD)lpOutBuf);				
            return TRUE;
            
        case IOCTL_HAL_GET_CPU_MINRATIO:
            GetCPUMinRatio((LPDWORD)lpOutBuf);				
            return TRUE;            
            
        case IOCTL_HAL_GET_CPU_MAXVID:
            GetCPUMaxVID((LPDWORD)lpOutBuf);			
            return TRUE;
        
        case IOCTL_HAL_GET_CPU_MINVID:
            GetCPUMinVID((LPDWORD)lpInBuf, (LPDWORD)lpOutBuf);			
            return TRUE;
                
        case IOCTL_HAL_GET_CPU_SUPPORTVIDS:
            *lpBytesReturned = GetSupportVID(nOutBufSize, (LPDWORD)lpOutBuf);			
            return TRUE;
            
        case IOCTL_HAL_GET_CPU_BESTRATIO:
            GetCPUBestRatio((LPDWORD)lpInBuf, (LPDWORD)lpOutBuf);			
            return TRUE;
        
       case IOCTL_HAL_SET_RNG_RATE:
        
        //RETAILMSG(1,(TEXT("powersaver_ctl.c ln189 lpInBuf=0x%X"),lpInBuf));
        if (!((LPDWORD)lpInBuf))
        {
          // SetLastError(ERROR_INVALID_PARAMETER);
        //    RETAILMSG(1,(TEXT("powersaver_ctl.c ln193")));
           return FALSE;
        }

        if (nInBufSize >= 4)
        {
           dwRNGRate = *(LPDWORD)lpInBuf;
        //   RETAILMSG(1,(TEXT("powersaver_ctl.c ln200 dwRNGRate=%d"),dwRNGRate));
           return TRUE;
        }
        else
        {
         //  SetLastError(ERROR_INVALID_PARAMETER);
           return FALSE;
        }
              	                                        	            
     
    default:
#ifdef INTERNAL_HAL_TESTING
        return InternalHalTesting(dwIoControlCode, lpInBuf, nInBufSize, lpOutBuf, nOutBufSize, lpBytesReturned);
#else
       // SetLastError(ERROR_NOT_SUPPORTED);
        return FALSE;
#endif
    }
    
    return FALSE;
}
