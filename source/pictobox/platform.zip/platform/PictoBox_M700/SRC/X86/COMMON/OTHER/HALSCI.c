
#include <windows.h>
#include <oal.h>
#include <bootarg.h>
#include <sci.h>

#ifdef DEBUG
//
// Debug zones
//
//#define ZONE_ERROR      DEBUGZONE(0)
//#define ZONE_WARNING    DEBUGZONE(1)
#define ZONE_FUNCTION   DEBUGZONE(2)
//#define ZONE_INIT       DEBUGZONE(3)
#define ZONE_PCMCIA     DEBUGZONE(4)
#define ZONE_IO         DEBUGZONE(5)
#define ZONE_MISC       DEBUGZONE(6)

#endif  // DEBUG

#define NOT_SUPPORT	0x0
#define VT686		0x1
#define VT8231		0x2
#define VT8233		0x3
#define VT8235		0x4
#define VT8237          0x5
#define VT8324		0x6
#define VT8251		0x7
#define VT8237A         0x8
#define VT8237S		0x9
#define VT8353		0xA

#define POWERBUTTON             0x01
#define EXTSMI                  0x02
#define GPIO4                   0x03
#define THERM                   0x04
#define NOTHING                 0x00

typedef VOID (WINAPI *PPWMFUNC)(DWORD);



void ScreenOff(void);
void ScreenOn(void);
void SusToDisk(DWORD);

BOOL GetIOBaseIRQ(DWORD,DWORD);

extern BOOL OEMIoControl(DWORD ,LPVOID,DWORD,LPVOID ,DWORD ,LPDWORD);

DWORD ChipSetID;

DWORD  dwIrqId, dwIOBase, PWM_Config,  SB686A_configid=0;
DWORD dwConfigId;
WORD   dwGPIOSTS,dwSusTo;
TCHAR szFileName[80];
TCHAR VendorFile[80];

DWORD  AutoConfig=1, IrqSetting, dwSLPBTN;

DWORD  F0CFGID = 0,F4CFGID = 0,CHIP = NOT_SUPPORT;
BOOL bVendorFunc = FALSE;
BOOL bVendorRequest = FALSE;
static BOOL bWakeOnKb = 0;
extern void NKSleep(DWORD);
//------------------------------------------------------------------------------
//
//  Function:  OALIoCtlSCIPWM
//

BOOL OALIoCtlSCIPWM( 
    UINT32 dwIoControlCode,
    PBYTE lpInBuf,
    UINT32 nInBufSize,
    PBYTE lpOutBuf,
    UINT32 nOutBufSize,
    UINT32* lpBytesReturned
) 
{
    
    BOOL bResult;
    
//    DWORD dwGetIOBase, dwGetIrqId;
 //   DWORD dwIOBase,dwIRQ;
  
  //  DEBUGMSG(0, (TEXT("+OALIoCtlSCIPWM %X\r\n"), dwIoControlCode));
  //    RETAILMSG(1, (TEXT("+OALIoCtlSCIPWM %X\r\n"), dwIoControlCode));
    switch (dwIoControlCode) {
		
		case IOCTL_HAL_POWEROFF:

			bResult=GetIOBaseIRQ(dwIOBase, dwIrqId);
	
			SusToDisk(dwIOBase);
			return TRUE;

		case IOCTL_HAL_SCREENOFF:
		       
			GetIOBaseIRQ( dwIOBase , dwIrqId);
						
			
			if ( (ChipSetID == 0x82351106) || (ChipSetID == 0x30571106) || (ChipSetID == 0x30741106) || (ChipSetID == 0x31471106) || (ChipSetID == 0x31771106)|| (ChipSetID == 0x32271106)||(ChipSetID == 0x83241106)||(ChipSetID == 0x32871106)||(ChipSetID == 0x33371106)||(ChipSetID == 0x33721106)||(ChipSetID == 0x83531106))
			{
				
				ScreenOff();
				//ThrottleOn();
			}
			else
				SusToDisk(dwIOBase);
			return TRUE;

		case IOCTL_HAL_SCREENON:
			GetIOBaseIRQ(dwIOBase ,dwIrqId);
			
			
			if ( (ChipSetID == 0x82351106) || (ChipSetID == 0x30571106) || (ChipSetID == 0x30741106) || (ChipSetID == 0x31471106) || (ChipSetID == 0x31771106) || (ChipSetID == 0x32271106)||(ChipSetID == 0x83241106)||(ChipSetID == 0x32871106)||(ChipSetID == 0x33371106)||(ChipSetID == 0x33721106)||(ChipSetID == 0x83531106))
			{
				
				ScreenOn();
				//ThrottleOff();
			}
			else
				SusToDisk(dwIOBase);
			return TRUE;
			
		        		        		        		        		

	}
//RETAILMSG(1, (TEXT("-OALIoCtlSCIPWM %X\r\n")));
    return 0;
}

//------------------------------------------------------------------------------




void ScreenOn(void)
{
    DEBUGMSG( ZONE_IO, (TEXT("SCIPWM:turn on screen\r\n")));
    RETAILMSG(1,(TEXT("SCIPWM:turn on screen\r\n")));
    _asm {
        mov dx,3c0h   //reset flip-flop
        in  al,dx

        mov al,20h
        out dx,al     //turn on screen
        in  al,dx
        out dx,al


        mov dx,3c4h  //Enable CRTC R/W
        mov al,01h
        out dx,al

        inc dx      //port 3c5h
        in  al,dx
        and al,0d7h
        out dx,al
    }
}

void ScreenOff(void)
{
    DEBUGMSG( ZONE_IO, (TEXT("SCIPWM:turn off screen\r\n")));
    RETAILMSG(1,(TEXT("SCIPWM:turn off screen\r\n")));
    _asm {
        mov dx,3c0h   //reset flip-flop
        in  al,dx

        xor al,al
        out dx,al     //turn off screen
        in  al,dx
        out dx,al

        mov dx,3c4h  //disable CRTC R/W
        mov al,01h
        out dx,al

        inc dx      //port 3c5h
        in  al,dx
        or  al,28h
        out dx,al
    }
}




void SusToDisk(DWORD dwIOBase)
{
    int  i;
    DEBUGMSG(ZONE_IO, (TEXT("SCIPWM: STD\r\n")));
    if(bWakeOnKb)
    {
	

    if (CHIP > VT686)
    {
       _asm
       {
            mov  eax, F0CFGID
            or   eax, 50h
            mov  edx, 0cf8h
            out  dx, eax

            mov  edx, 0cfch
            in   eax, dx
            or   ax, 0200h
            out  dx, eax 
      }

      switch (CHIP)
      {
         case 2:
             _asm
             {
                   mov  ax, 0e0h
                   mov  dx, 03f0h
                   out  dx, al
  
                   mov  dx, 03f1h
                   in   al, dx
                   or   al, 81h
                   out  dx, al 
             }
             break;

         case 3:
         case 4:
         case 5:
         case 6:
         case 7:
         case 8:
         case 9:
         case 0xa:
         
             _asm
             {
                   mov  ax, 0e0h
                   mov  dx, 02eh
                   out  dx, al
  
                   mov  dx, 02fh
                   in   al, dx
                   or   al, 89h
                   out  dx, al 
             }
             break;
      }
    }
}

    for ( i = 0; i < 5; i++)
    {
    
        _asm
        {
              ;;------Disable Reg.-------
              mov    eax, 0
	      ;; Power Management Enable (Offset 5-2)
              mov    edx, dwIOBase
              add    edx, 02h
              out    dx, eax
              jmp    short $+2               ;delay time

              ;; General Purpose Enable (Offset 25-22)
              mov    edx, dwIOBase
              add    edx, 22h
              out    dx, eax
              jmp    short $+2

              ;; Global Control Enable (Offset 2D-2A)
	      mov    edx, dwIOBase
              add    edx, 02ah
              out    dx, eax
              jmp    short $+2

              ;; Primary Activity Detect Enable (Offset 37-34)
	      mov    edx, dwIOBase
              add    edx, 034h
              out    dx, eax
              jmp    short $+2
              
              ;;------Enable Reg.-------
              mov    eax, 0ffffffffh;
              ;; Power Management Status (Offset 1-0)
              mov    edx, dwIOBase
              out    dx, ax
              jmp    short $+2

              mov    edx, dwIOBase
              add    edx, 020h
              out    dx, ax
              jmp    short $+2

              ;; General Status (Offset 28, 29)
              mov    edx, dwIOBase
              add    edx, 028h
              out    dx, ax
              jmp    short $+2

              ;; General Purpose Status (Offset 30-33)
              mov    edx, dwIOBase
              add    edx, 030h
              out    dx, eax
              jmp    short $+2

              mov    eax, 0h
              ;; Processor & PCI Bus Control (Offset 11-10)
              mov    edx, dwIOBase
              add    edx, 010h
              out    dx, ax
              jmp    short $+2
              
              
              ;;enable SMI
              mov  edx, dwIOBase
              add  edx, 24h
              in   ax, dx              
              or   ax, dwGPIOSTS
             ;or   ax, 0ffffh
              out  dx, ax

        }
    if(bWakeOnKb)
    {
    	
        _asm
        {
              mov    edx, dwIOBase
              add    edx, 22h
              in     eax, dx
              or     ax, 04h
              out    dx, eax
              jmp    short $+2

	}
    }
        if ( ChipSetID == 0x30401106 )
        {
           // VT82C586
           _asm
           {
                 mov    edx, dwIOBase
                 add    edx, 05h
                 mov    al, 20h
                 out    dx, al
           }
           
        }
        else
        { 
           // Suspend to Disk, set to 28h
           if(dwSusTo == 0) 
           {   
           
              _asm
              {
                 mov    edx, dwIOBase
                 ;; Power Management Control (Offset 5)
		 add    edx, 05h
                 mov    al, 28h
                 out    dx, al
              }
              //RETAILMSG(1, (TEXT("SCIPWM:Set suspend to disk.\n"))); 
        
           }
           else // Suspend to Ram, set to 24h
           {
               _asm
              {
                 mov    edx, dwIOBase
                 ;; Power Management Control (Offset 5)
		 add    edx, 05h
                 mov    al, 24h
                 out    dx, al
              }
              //RETAILMSG(1, (TEXT("SCIPWM:Set suspend to ram.\n")));
           }
          
        }
     
         NKSleep(200);
     
    }
    
}



BOOL GetIOBaseIRQ(DWORD dwGetIOBase, DWORD dwGetIRQ)
{
    ULONG               portBase, ACPI_Irq;
    BOOL                bFoundIt;
    DWORD               configid, deviceid;
   
    WORD GenPurEV_Sts;
   
    bFoundIt = FALSE;
   

    for ( configid = 0x80000000; configid < 0x80010800; configid += 0x100 )
    {
        _asm
        {
            mov  eax, configid
            mov  edx, 0cf8h
            out  dx, eax

            mov  edx, 0cfch
            in   eax, dx
            mov  deviceid, eax
        }
         
        if (deviceid == 0x06861106) {
           SB686A_configid=configid;
           F0CFGID = configid;
           CHIP = VT686;
        }
        else if(deviceid == 0x82311106)
        {
           F0CFGID = configid;
           CHIP = VT8231;
       
        }
     

       	if ( (deviceid == 0x30741106) || (deviceid == 0x31471106) || (deviceid == 0x31771106)|| (deviceid == 0x32271106)|| (deviceid == 0x83241106)|| (deviceid == 0x32871106)|| (deviceid == 0x33371106) || (deviceid == 0x33721106)|| (deviceid == 0x83531106))
	{
            ChipSetID = deviceid;
            
            // Enable ACPI IO Address, and Get ACPI IO Base, and ACPI Irq
            if(deviceid == 0x31471106)
            {
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8233;
            }
            if(deviceid == 0x31771106)
            {
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8235;
            }
            else if(deviceid == 0x32271106)
            {
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8237;
            }
             if(deviceid == 0x32871106)
            {
            	
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8251;
            }
            if(deviceid == 0x83241106)
            {
            	
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8324;
            }
            if(deviceid == 0x33371106)
            {
            	
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8237A;
            }
            
            if(deviceid == 0x33721106)
            {
            	
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8237S;
            }
            
            if(deviceid == 0x83531106)
            {
            	
            	F0CFGID = F4CFGID = configid;
            	CHIP = VT8353;
            	
            }            
                    
            _asm
	    {
                    mov    eax, configid
                    add    ax, 080h
                    mov    edx, 0cf8h
                    out    dx, eax

                    mov    edx, 0cfch
                    in     eax, dx
                    mov    ACPI_Irq, eax              ; ACPI_IRQ's value : Offset80-83 bits
                    or     eax, 00008000h             
                    out    dx, eax

                    mov    eax, configid
                    add    eax, 088h
                    mov    edx, 0cf8h
                    out    dx, eax

                    mov    edx, 0cfch
                    in     eax, dx
                    and    eax, 0fffffffeh
                    mov    portBase, eax 
	    }
	
           if (!AutoConfig)
           {
              WORD wtemp = 1 << IrqSetting;
              ACPI_Irq = IrqSetting << 16;
              _asm
              {
                  mov    eax, configid
                  add    ax, 080h
                  mov    edx, 0cf8h
                  out    dx, eax

                  mov    edx, 0cfch
                  in     eax, dx
                  and    eax, 0fff0ffffh
                  or     eax, ACPI_Irq
                  out    dx, eax

                  mov    dx, 04d0h
                  in     ax, dx
                  or     ax, wtemp
                  out    dx, ax
              }
          
           RETAILMSG(1, (TEXT("SCIPWM:Assign SCI IRQ:0x%x\r\n"), IrqSetting));
           }

           ACPI_Irq = ACPI_Irq >> 16;
           ACPI_Irq = ACPI_Irq & 0x0000000f;
	  
	   if (ACPI_Irq == 0)
           {
           	
              //DEBUGMSG(1, (TEXT("SCIPWM: Please Assign Irq for ACPI\r\n")));
              ACPI_Irq=0x9;
              RETAILMSG(1,(TEXT("Assign IRQ=0x9 for ACPI\r\n")));
              //return FALSE;
           }

	   // Install IRQ sharing, dwSysIntr : return the sharing system IRQ
	   //bResult=InstallIRQShare((DWORD)ACPI_Irq, (PVOID)portBase, configid, &dwSysIntr);
	   
	  
	   //ACPI_Irq = (ULONG)dwSysIntr; // Assigned as sharing IRQ
	  
           bFoundIt = TRUE;           
           PWM_Config = configid;
           dwGetIOBase=portBase;
           dwGetIRQ=ACPI_Irq;
           DEBUGMSG(ZONE_INIT, (TEXT("SCIPWM: Irq 0x%X, IOBase 0x%X\r\n"), ACPI_Irq, portBase));

          
           break;		     
           }                          
               
        if ( (deviceid == 0x30571106) || (deviceid == 0x30501106) || (deviceid == 0x30401106)
              || (deviceid == 0x82351106 ) )
        {
           
           if(deviceid == 0x30571106)
           {
              F4CFGID = configid;              
           }
           else if(deviceid == 0x82351106)
           {
              	
              F4CFGID = configid;
           
           }
           
           ChipSetID = deviceid;
           
           // Enable ACPI IO Address, and Get ACPI IO Base, and ACPI Irq
           if(dwSLPBTN == 1)
           {
              _asm
              {
                  mov    eax, configid
                  add    ax, 040h
                  mov    edx, 0cf8h
                  out    dx, eax

                  mov    edx, 0cfch
                  in     eax, dx
                  mov    ACPI_Irq, eax                           
                  ;or     eax, 00008000h
                  or     eax, 00008040h      ;Enable sleep button
                  out    dx, eax
              }
           }
           else
           {
              _asm
              {
                  mov    eax, configid
                  add    ax, 040h
                  mov    edx, 0cf8h
                  out    dx, eax

                  mov    edx, 0cfch
                  in     eax, dx
                  mov    ACPI_Irq, eax                           
                  or     eax, 00008000h                  
                  out    dx, eax
              }
           }
           
      
           
           _asm{
               mov    eax, configid
               add    eax, 048h
               mov    edx, 0cf8h
               out    dx, eax

               mov    edx, 0cfch
               in     eax, dx
               and    eax, 0fffffffeh
               mov    portBase, eax
           }

           // For VT82C586B Rev. 3040E
           if ( (deviceid == 0x30401106) && ( (portBase == 0) || (portBase == 0xfffffffe) ) )
           {
              _asm{
                  mov    eax, configid
                  add    eax, 048h
                  mov    edx, 0cf8h
                  out    dx, eax

                  mov    edx, 0cfch
                  in     eax, dx
                  and    eax, 0fffffffeh
                  mov    portBase, eax
              }
           }
		    
           if (!AutoConfig)
           {
              WORD wtemp = 1 << IrqSetting;
              ACPI_Irq = IrqSetting << 16;
              _asm
              {
                  mov    eax, configid
                  add    ax, 040h
                  mov    edx, 0cf8h
                  out    dx, eax

                  mov    edx, 0cfch
                  in     eax, dx
                  and    eax, 0fff0ffffh
                  or     eax, ACPI_Irq
                  out    dx, eax

                  mov    dx, 04d0h
                  in     ax, dx
                  or     ax, wtemp
                  out    dx, ax
              }
              RETAILMSG(1, (TEXT("SCIPWM:Assign SCI IRQ:0x%x\r\n"), IrqSetting));
           }
	 
           ACPI_Irq = ACPI_Irq >> 16;
           ACPI_Irq = ACPI_Irq & 0x0000000f;
	 
	   if (ACPI_Irq == 0)
           {
           
              DEBUGMSG(1, (TEXT("SCIPWM: Please Assign Irq for ACPI\r\n")));
              
              return FALSE;
           }
	
	   // Install IRQ sharing, dwSysIntr : return the sharing system IRQ
	
	//  bResult=InstallIRQShare((DWORD)ACPI_Irq, (PVOID)portBase, configid, &dwSysIntr);
	
	 
	//   ACPI_Irq = (ULONG)dwSysIntr; // Assigned as sharing IRQ
	 
           bFoundIt = TRUE;
           PWM_Config = configid;
           dwGetIOBase=portBase;           
           dwGetIRQ=ACPI_Irq;
           DEBUGMSG(ZONE_INIT, (TEXT("SCIPWM: Irq 0x%X, IOBase 0x%X\r\n"), ACPI_Irq, portBase));
           
           break;
        }

    }
    
    if (!bFoundIt) return bFoundIt;
    
    dwIOBase=portBase;   
    dwIrqId=ACPI_Irq;
    dwConfigId=configid;
    

  
    // Enable SCI
    _asm
    {
        mov  edx, dwIOBase
        add  edx, 04h
        in   al, dx
        or   al, 01h            ; Enable SCI
        out  dx, al

        mov  edx, dwIOBase
        add  edx, 24h
        in   ax, dx
        ;and  ax, 0fffeh
        and  ax, 0ff00h
        out  dx, al             ; Disable ALL GPIO to generate SMI

        mov  edx, dwIOBase      ;clear current status offset 0h-1h & 20h-21h
        mov  ax,0xffff          ;
        out  dx,ax
        add  dx,20h
        out  dx,ax
    }
    
    

    //Check current general purpose status
    do {
       _asm
       {
           mov  edx, dwIOBase
           add  edx, 20h
           in   ax, dx
           mov  GenPurEV_Sts, ax    ;GenPurEV_Sts : Offset21-20 bits
           out  dx, ax
       }
      DEBUGMSG(ZONE_IO, (TEXT("SCIPWM: General Purpose status:%04XH\r\n"),GenPurEV_Sts));
    } while(GenPurEV_Sts);
    
    
    if(dwSLPBTN == 1)
    {
       _asm {
          mov  edx, dwIOBase  ;enable pwr button
          add  dx,3h
          mov  al,0x3 
          out  dx,al
       }
    }
    else
    {
       _asm {
          mov  edx, dwIOBase  ;enable pwr button
          add  dx,3h
          mov  al,0x1
          out  dx,al
       }
    }
    

    _asm {
            mov  edx, dwIOBase
            add  edx, 22h
            in   ax, dx
            or   ax, 0401h          ;THERM|EXT_SMI
            out  dx, ax
        }
    

	
    return bFoundIt;
}




