//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
//------------------------------------------------------------------------------
//
//  Header: ioctl_tab.h
//
//  Configuration file for the OAL IOCTL component.
//
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//  RESTRICTION
//
//  This file is included by the platform's ioctl.c file and defines the 
//  global IOCTL table, g_oalIoCtlTable[]. Therefore, this file may ONLY
//  define OAL_IOCTL_HANDLER entries. 
//
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//  Architecture
//
//  Desc... - ioctl are pre-emptible, code is multi-threaded, user responsible
//            for managing this.
//
//  Format:
//
//  IOCTL CODE,                                 Flag        Handler Function
//------------------------------------------------------------------------------

    { IOCTL_HAL_REQUEST_SYSINTR,                0,          OALIoCtlHalRequestSysIntr   },
    { IOCTL_HAL_RELEASE_SYSINTR,                0,          OALIoCtlHalReleaseSysIntr   },
    { IOCTL_HAL_REQUEST_IRQ,                    0,          OALIoCtlHalRequestIrq       },

    { IOCTL_HAL_DDK_CALL,                       0,          x86IoCtlHalDdkCall          },

    { IOCTL_HAL_DISABLE_WAKE,                   0,          x86PowerIoctl               },
    { IOCTL_HAL_ENABLE_WAKE,                    0,          x86PowerIoctl               },
    { IOCTL_HAL_GET_WAKE_SOURCE,                0,          x86PowerIoctl               },
    { IOCTL_HAL_PRESUSPEND,                     0,          x86PowerIoctl               },

    { IOCTL_HAL_GET_CACHE_INFO,                 0,          x86IoCtlHalGetCacheInfo     },
    { IOCTL_HAL_GET_DEVICEID,                   0,          OALIoCtlHalGetDeviceId      },
    { IOCTL_HAL_GET_DEVICE_INFO,                0,          OALIoCtlHalGetDeviceInfo    },
    { IOCTL_HAL_SET_DEVICE_INFO,                0,          x86IoCtlHalSetDeviceInfo    },
    { IOCTL_HAL_GET_UUID,                       0,          OALIoCtlHalGetUUID          },
    { IOCTL_HAL_GET_RANDOM_SEED,                0,          OALIoCtlHalGetRandomSeed    },
    
    { IOCTL_PROCESSOR_INFORMATION,              0,          x86IoCtlProcessorInfo       },
    
    { IOCTL_HAL_INIT_RTC,                       0,          x86IoCtlHalInitRTC          },
    { IOCTL_HAL_REBOOT,                         0,          x86IoCtlHalReboot           },

    { IOCTL_HAL_ILTIMING,                       0,          x86IoCtllTiming             },

    { IOCTL_HAL_POSTINIT,                       0,          x86IoCtlPostInit            },
    
    { IOCTL_HAL_QUERY_DISPLAYSETTINGS,          0,          x86IoCtlQueryDispSettings   },

    { IOCTL_HAL_INITREGISTRY,                   0,          x86IoCtlHalInitRegistry     },
        //VIA SCIPWM
    { IOCTL_HAL_POWEROFF,			0,          OALIoCtlSCIPWM    	 	},
    { IOCTL_HAL_SCREENOFF,  			0,          OALIoCtlSCIPWM    	 	},
    { IOCTL_HAL_SCREENON,       		0,	    OALIoCtlSCIPWM    	 	}, 
    { SCI_IOCTL_SETSCIREG,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_ACPOWERINIT,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_GETCHIPSETID,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_DLLPOWERUP,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_DLLGPIO,              		0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_GENPURSTATUS,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_ACPOWERLOSS,           		0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_FANOFF,        			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_CLEARSTATUSBIT,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_SUSTORAM,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_SUSTODISK,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_SCREENON,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_SCREENOFF,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_THROTTLEON,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_THROTTLEOFF,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_GETIOBASE,			0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_GETIRQ,				0,	    OALIoCtlSCIPWM    	 	},
    { SCI_IOCTL_GETCONFIGID,			0,	    OALIoCtlSCIPWM    		},
    //PowerSaver
    { IOCTL_HAL_SET_PERIOD,             	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_IDLE_THRESHOLDHIGH,         0,          PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CURRENT_RATIO,      	0,          PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_DEFAULT_RATIO,      	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_ADJUST_FREQUENCY_MODE,  	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_IDLE_THRESHOLDLOW,  	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_CURRENT_RATIO,      	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_ADJUST_SOFTVID_MODE,    	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CURRENT_VID,       		0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_CURRENT_VID,       		0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_RATIO_COUNTER,      	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_RATIO_COUNTER,      	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_AUTO_VID,           	0,     	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_AUTO_VID,           	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_VRM_TYPE,           	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_TYPE,           	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_IdelTime,       	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_Set_SOFTVID_FLAG,       	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_Get_SOFTVID_FLAG,       	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_GPO_BASEADDR,       	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_GPO_NUMBER,         	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_CPU_MINIRATIO,      	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_CPU_MAXVID,         	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_CPU_MINIVID,        	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_CHANGE_CPURTAIO_FLAG, 		0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_MAXRATIO,        	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_MAXVID, 		0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_MINRATIO,        	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_MINVID,          	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_SUPPORTVIDS,          	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_GET_CPU_BESTRATIO,          	0,	    PowSaverOEMIoControl	},
    { IOCTL_HAL_SET_RNG_RATE,			0,	    PowSaverOEMIoControl	},	
    // Required Termination
    { 0,                                        0,          NULL                        }
