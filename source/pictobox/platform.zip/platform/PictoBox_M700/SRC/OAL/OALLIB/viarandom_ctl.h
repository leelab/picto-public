#include <windows.h>
#include <winioctl.h>

#define IOCTL_HAL_SET_RNG_RATE   CTL_CODE(FILE_DEVICE_HAL, 0x3001, METHOD_BUFFERED, FILE_ANY_ACCESS)
//#define IOCTL_HAL_GET_VIARANDOM_SEED   CTL_CODE(FILE_DEVICE_HAL, 0x2002, METHOD_BUFFERED, FILE_ANY_ACCESS)

BOOL RandomOEMIoControl( 
    UINT32 dwIoControlCode,
    PBYTE lpInBuf,
    UINT32 nInBufSize,
    PBYTE lpOutBuf,
    UINT32 nOutBufSize,
    UINT32* lpBytesReturned
    );