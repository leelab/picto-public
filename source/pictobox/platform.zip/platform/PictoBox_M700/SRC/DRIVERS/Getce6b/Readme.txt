**
**
**  VIA Velocity Family Gigabit Ethernet Adapter
**
**  NDIS Driver for Windows CE 6.0
**
**  v1.58   Jul, 2007
**
**

Introduction:
=============

  This document shows you how to setup the driver in Windows CE 6.0 operating system.

Contents of the Subdirectory:
=============================

    GETCE6B.DLL         The NDIS5 driver for Windows CE 6.0.
    GETCE6B.MAP         driver MAP file.
    GETCE6B.PDB         driver PDB file.
    GETCE6B.REL         driver REL file.
    GETCE6B.REG         driver sample REG file.
    GETCE6B.BIB         driver sample BIB file.
    README.TXT          this readme file.


Installation:
=============

  Before starting with the installation process, make sure that the adapter
  is properly installed and configured.


    1. System hardware configuration:
       An IRQ line must be assigned to the gigabit Ethernet controller
       by the system BIOS.

    2. Create and build a new platform:
       Assume a new platform based on CEPC:X86 BSP is created in Platform Builder for CE6.0
       and choose a suitable platform configuration such as
       Industrial Device -> Internet Appliance.

    3. Select "Sysgen" from the build options "Advanced Build Commands" on "Build" menu to build the OS image.

    4. Driver Installation:
       Please execute GETCE6B.MSI to the target installation directory:
       $(_WINCEROOT)\3rdParty\Via\

       Copy driver related files, GETCE6B.DLL/MAP/PDB/REL, to the $(_FLATRELEASEDIR) directory:
       $(_WINCEROOT)\OSDesigns\<project name>\RelDir\<OS design configuration>\

       For example, if your OS design is named OSDesignTest and you are building a run-time image for a CEPC,
       put files in $(_WINCEROOT)\OSDesigns\OSDesignTest\RelDir\CEPC_x86_Release.

    5. Add VIA Velocity Family Network Device Driver to OS Design:
       In Solution Explorer, locate to the Parameter Files folder in your OS design, and then modify the
       Project.bib file located in the folder for your target device, such as "CEPC".

       Sample "GETCE6B.BIB" file for your reference.

    6. Modify the registry settings:
       Network interface needs a Registry configuration in the Platform.reg which is located in
       $(_FLATRELEASEDIR) directory and you should add VIA GETCE6B Driver Registry in it for
       VIA Velocity Family Network Device.

       Sample "GETCE6B.REG" file for your reference and find details in Note 2.

    7. Select "Make Run-Time Image" from "Build" menu to build run-time image for your target device.

    8. Download the binary image to your target platform.


  Note:

    1. Basic connection testing:
       On the development workstation, open a command prompt and type:

         ping  <IP address of the target device>

       As an example, if the network card's IP address in the target platform
       is 192.168.60.100, then type:

         ping 192.168.60.100

       If the driver is installed correctly and the network card works
       properly, the following messages will appear on the development workstation:

         Pinging 192.168.60.100 with 32 bytes of data:

         Reply from 192.168.60.100: bytes=32 time<10ms TTL=32
         Reply from 192.168.60.100: bytes=32 time<10ms TTL=32
         Reply from 192.168.60.100: bytes=32 time<10ms TTL=32
         Reply from 192.168.60.100: bytes=32 time<10ms TTL=32

       Note values for "time" and "TTL" may vary from system to system.
       If the network card or the driver itself fails to work properly,
       the following messages will appear on the development workstation:

         Pinging 192.168.60.100 with 32 bytes of data:

         Request timed out.
         Request timed out.
         Request timed out.
         Request timed out.

    2. Update registry PLATFORM.REG:
       You should add VIA GETCE6B Driver Registry into PLATFORM.REG which is located in
       $(_WINCEROOT)\OSDesigns\<project name>\RelDir\<OS design configuration>\.

       Read below for more information on how to configure the driver settings.

       The GETCE6B driver use several registry sub-keys under the
       [HKEY_LOCAL_MACHINE\Comm\GETCE6B\Parms] key.

       The PCIBus of "BusType" is designated by 0x05.
       The media type of "ConnectionType" is designated below:

         MEDIA_AUTO              0x00
         MEDIA_100M_HALF         0x01
         MEDIA_100M_FULL         0x02
         MEDIA_10M_HALF          0x03
         MEDIA_10M_FULL          0x04


       "BusNumber" and "SlotNumber" specify the bus and slot(device) numbers of
       the GETCE6B network controller on the PCI bus. "BusNumber" is 0 normally.
       If "SlotNumber" is given, the driver will access GETCE6B through the
       specified bus and slot numbers.
      
       The sub-keys under [HKEY_LOCAL_MACHINE\Comm\GETCE6B1\Parms\TcpIp]
       are addresses for IP, gateway, and subnetmask. The listed values
       are used as an example, and these keys must be
       modified according to your actual network environments.
       If a DHCP server exists in your network, set the sub-keys as below
       to enable the DHCP configuration,
      
         [HKEY_LOCAL_MACHINE\Comm\GETCE6B1\Parms\TcpIp]
               "EnableDHCP"=dword:1
               "DefaultGateway"=""
               "UseZeroBroadcast"=dword:0
               "IpAddress"=""
               "Subnetmask"=""
               "DNS"=""
               "WINS"=""
