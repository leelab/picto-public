1.  This software package is a 7.06.32.34-00000 driver . This driver release 
    supports CRT, LCD,DVI and TV combinations. A variety of display resolutions,
    color depths and refresh rates are supported by registry settings. 
    The driver works properly with Microsoft Windows Embedded CE 6.0.

2.  (1).support chip:VX800
    (3).Its install direction is 
        C:\WINCE600\PLATFORM\VIABSP and C:\WINCE600\PLATFORM\VIACEPC
        The first one is for VIA BSP; and the second one is for MS cepc.
        If you have intalled via bsp, this msi will overwrite original display driver in your via bsp.
        If your platform uses via bsp, you may don't need to do other things.
        If your platform uses MS cepc, you need to select:
        Third Party---> Device Drivers---->VIA Ddrawcle Display Driver

 
3.  File descriptions
    \DEBUG\DDI_VIA.DLL             	Display Driver debug version
    \DEBUG\DDI_VIA.MAP             	MAP debug file
    \DEBUG\DDI_VIA.PDB             	PDB debug file
    \DEBUG\DDI_VIA.REL             	REL debug file
    \DEBUG\d3dm_via.DLL             	D3DM Driver debug version
    \DEBUG\d3dm_via.MAP             	MAP debug file
    \DEBUG\d3dm_via.PDB             	PDB debug file
    \DEBUG\d3dm_via.REL             	REL debug file
    \DEBUG\GetCRTRes.exe               Get Monitor's EDID informations    
    \DEBUG\GetCRTRes.rar               GetCRTRes.exe application source code
    \DEBUG\Access_I2C.exe              I2C R/W sample application
    \DEBUG\Access_I2C.rar              source code of I2C_RW_Sample.exe
    \DEBUG\ShowImg.dll                 Show test pattern for SetDisplayMode()
    \DEBUG\ShowImg.rar                 ShowImg.dll source code
    \DEBUG\TestDisplayMode.exe         Display mode test tool
    \DEBUG\TestDisplayMode.rar         source code of TestDisplayMode.exe
    
       
    \RETAIL\DDI_VIA.DLL                 Display Driver retail version
    \RETAIL\DDI_VIA.MAP                 MAP retail file
    \RETAIL\DDI_VIA.PDB                 PDB retail file
    \RETAIL\DDI_VIA.REL                 REL retail file
    \RETAIL\d3dm_via.DLL             	D3DM Driver retail version
    \RETAIL\d3dm_via.MAP             	MAP debug file
    \RETAIL\d3dm_via.PDB             	PDB debug file
    \RETAIL\d3dm_via.REL             	REL debug file 
    \RETAIL\GetCRTRes.exe               Get Monitor's EDID informations    
    \RETAIL\GetCRTRes.rar               GetCRTRes.exe application source code
    \RETAIL\I2C_RW_Sample.exe           I2C R/W sample application
    \RETAIL\I2C_RW_Sample.rar           source code of I2C_RW_Sample.exe
    \RETAIL\ShowImg.dll                 Show test pattern for SetDisplayMode()
    \RETAIL\ShowImg.rar                 ShowImg.dll source code
    \RETAIL\TestDisplayMode.exe         Display mode test tool
    \RETAIL\TestDisplayMode.rar         source code of TestDisplayMode.exe
    
    \Utility\DEBUG\VTUtility.exe        Tool to Change display setting debug version
    \Utility\RETAIL\VTUtility.exe       Tool to Change display setting retail version

    \VideoPreview\DEBUG\LoadDll.exe    
    \VideoPreview\DEBUG\VCaptureSuf.dll
    \VideoPreview\RETAIL\LoadDll.exe   
    \VideoPreview\RETAIL\VCaptureSuf.dll
  
    DDRAWCLE.REG                    Sample reg file  
    DRRAWCLE.bib                    project-specific binary image builder (.bib) 
    DRRAWCLE.pbpxml                 Platform Builder project (.pbpxml) file    
    README.TXT            
    postlink.bat
    prelink.bat
    projSysgen.bat
    sources 

4.  Modify the registry settings in DDRAWCLE.REG
    You can modify DDRAWCLE.REG to meet your requests.

