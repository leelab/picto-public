//This is a simple program that generates fake data.

 #include <QCoreApplication>
#include <QString>
#include <QList>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QTextStream>
#include <qDebug>
#include <math.h>


#define NUM_TRIALS 100
#define AVG_EVENTS_PER_TRIAL 15
#define AVG_SPIKES_PER_TRIAL 100

#define TRIAL_DURATION_MEAN 5.0
#define TRIAL_DURATION_STDDEV 1.0

typedef struct SpikeStruct_st{
	int channel;
	char unit;
	float timestamp;
	QList<float> waveform;
}SpikeStruct;

typedef struct EventStruct_st{
	float timestamp;
	int eventCode;
}EventStruct;

typedef struct{
	int trialNum;
	float trialStart;
	float trialEnd;
	QList<EventStruct_st> events;
	QList<SpikeStruct_st> spikes;
}TrialStruct;


QTextStream outputStream(stdout);

QSqlDatabase neuralDB;
QSqlDatabase beahvioralDB;
QList<TrialStruct> experiment;

void createExperiment();
void initDb();
void genNeuralData();
void genBehavData();
double normal(const double &mean, const double &std);


void main(int argc, char* argv[])
{
	QCoreApplication app(argc,argv);

	srand(100);
 
	createExperiment();
	initDb();
	genNeuralData();
	genBehavData();
}

//Ths creates the "real" experiment.
//The times are assumed to be the absolute correct times.  No jitter or errors.
void createExperiment()
{
	int trialNum = rand()%256;
	double timer;

	timer = 0.0;

	//run through the trials
	int trial;
	for(trial = 0; trial<NUM_TRIALS; trial++)
	{
		outputStream<<"-- Trial "<<trialNum<<" --\n";
		TrialStruct currTrial;
		currTrial.trialNum = trialNum;
		
		double trialDuration = normal(TRIAL_DURATION_MEAN, TRIAL_DURATION_STDDEV);
		if(trialDuration<0)
			trialDuration = TRIAL_DURATION_MEAN;
		currTrial.trialStart = timer;
		currTrial.trialEnd = timer + trialDuration;

		//generate trial events
		int numEvents = (int)(0.5 + normal(AVG_EVENTS_PER_TRIAL,AVG_EVENTS_PER_TRIAL/10.0));
		if(numEvents <= 0)
			numEvents = 1;
		timer = currTrial.trialStart;

		while(timer < currTrial.trialEnd)
		{
			EventStruct newEvent;
			newEvent.eventCode = rand()%25;
			double nextEventTime = normal(trialDuration/numEvents, trialDuration/numEvents/10.0);
			if(nextEventTime<0)
				nextEventTime = trialDuration/numEvents;
			timer += nextEventTime;
			
			if(timer > currTrial.trialEnd)
				break;

			newEvent.timestamp = timer;

			currTrial.events.push_back(newEvent);
		}

		outputStream<<currTrial.events.size()<<" events\n";

		//generate spike events
		int numSpikes = (int)(0.5 + normal(AVG_SPIKES_PER_TRIAL,AVG_SPIKES_PER_TRIAL/3.0));
		if(numSpikes<= 0)
			numSpikes = 1;
		timer = currTrial.trialStart;

		while(timer < currTrial.trialEnd)
		{
			SpikeStruct newSpike;
			newSpike.channel = rand() % 16 + 1;
			newSpike.unit = 'a' + rand()%4;

			double nextSpikeTime = normal(trialDuration/numSpikes, trialDuration/numSpikes/3.0);
			if(nextSpikeTime < 0)
				nextSpikeTime = trialDuration/numSpikes;
			timer += nextSpikeTime;

			if(timer > currTrial.trialEnd)
				break;
			newSpike.timestamp = timer;

			for(int i=0; i<64; i++)
				newSpike.waveform.push_back((float)((rand()%10000)/10000.0));

			currTrial.spikes.push_back(newSpike);
		}
		
		outputStream<<currTrial.spikes.size()<<" spikes\n";


		//add to the trial list
		experiment.push_back(currTrial);

		//increment the trialNum counter
		trialNum++;
		if(trialNum>255)
			trialNum = 0;

		//add inter-trial interval
		double interTrialInterval = 1.0 + normal(0,0.3);
		if(interTrialInterval < 0)
			interTrialInterval = 1.0;
		timer += interTrialInterval;
	outputStream.flush();
	}

	outputStream<<"Generated "<<trial<<" trials\n";
}

void initDb()
{
	outputStream<<"Setting up databases\n";


	neuralDB = QSqlDatabase::addDatabase("QSQLITE", "NeuralConnection");
	neuralDB.setDatabaseName(QCoreApplication::applicationDirPath() + "/../data/testNeuralDb.sqlite");
	bool result = neuralDB.open();
	if(!result)
	{
		qDebug()<<"Failed to open database";
		qDebug()<<"Error: "<<neuralDB.lastError().text();
		return;
	}

	beahvioralDB = QSqlDatabase::addDatabase("QSQLITE", "BehavioralConnection");
	beahvioralDB.setDatabaseName(QCoreApplication::applicationDirPath() + "/../data/testBehavioralDb.sqlite");
	result = beahvioralDB.open();
	if(!result)
	{
		qDebug()<<"Failed to open database";
		qDebug()<<"Error: "<<beahvioralDB.lastError().text();
		return;
	}

	outputStream.flush();

	return;

}

void genNeuralData()
{
	outputStream<<"Generating neuralData\n";
	outputStream.flush();

	//since the timestamps used by the Plexon/TDT are unrelated to the timestamps used by 
	//Picto, we'll need to create some sort of offset.  Since we are using a linear offset,
	//we are assuming that the clocks (although not snychronized) are running at the same
	//speed.  We could add an additional element of clock drift, but this seems like a bad
	//idea, since there shouldn't be any clock drift in the real system.
	double clockoffset = rand()%10000;
	double jitter;

	QSqlQuery query(neuralDB);
	//kill the tables left over from a previous session
	query.exec("drop table alignment");
	query.exec("drop table spikes");
	query.exec("drop table sessionInfo");

	//Set up the tables
	query.exec("create table alignment (id INTEGER PRIMARY KEY, timestamp REAL, aligncode INTEGER)");
	query.exec("create table spikes (id INTEGER PRIMARY KEY, timestamp REAL, channel TEXT, unit TEXT, waveform TEXT)");
	query.exec("create table sessionInfo (id INTEGER PRIMARY KEY, proxyName TEXT, proxyAddress TEXT, device TEXT, sampleRate REAL, startDate TEXT, startTime TEXT, endDate TEXT, endTime TEXT)");

	//generate the events first
	//We'll add a very slight amount of randomness to the timestamps
	//In Orion, the Plexon/TDT had a copy of every behavioral event that occured
	//In Picto, we're simply going to use an 8-bit rolling counter that marks the start
	//and end of each trial with an arbitrary trial number.  For example, a sequence of
	//trials would look like this:
	//     56,56,57,57,58,58,59,59,60,60...
	//The timestamp on the first number is the start of the trial, and the timestamp on
	//the second is the end.  Since the behavioral and neural clocks are running continuously,
	//this method will give us more than enough data points to align the neural
	//and behavioral data.
	neuralDB.transaction();

	QList<TrialStruct>::iterator trial = experiment.begin();
	while(trial != experiment.end())
	{
		jitter = normal(0,0.001);
		query.prepare("INSERT INTO alignment (timestamp,aligncode) "
			"VALUES(:timestamp, :aligncode)");
		query.bindValue(":timestamp", trial->trialStart + clockoffset + jitter);
		query.bindValue(":aligncode", trial->trialNum);
		query.exec();

		jitter = normal(0,0.001);
		query.prepare("INSERT INTO alignment (timestamp,aligncode) "
			"VALUES(:timestamp, :aligncode)");
		query.bindValue(":timestamp", trial->trialEnd + clockoffset + jitter);
		query.bindValue(":aligncode", trial->trialNum);
		query.exec();

		trial++;
	}

	//Next, we'll generate the spikes.  We don't need to add jitter here, because
	//the spike data is only included in the neural data, so we'd never be able to
	//tell if there were alignment issues
	trial = experiment.begin();
	while(trial != experiment.end())
	{
		QList<SpikeStruct>::iterator spike = trial->spikes.begin();
		while(spike != trial->spikes.end())
		{

			QString waveformStr;
			//convert waveform into text
			for(int i=0; i<spike->waveform.size(); i++)
			{
				waveformStr += spike->waveform[i];
				waveformStr += " ";
			}

			query.prepare("INSERT INTO spikes (timestamp,channel,unit,waveform) "
				"VALUES(:timestamp, :channel, :unit, :waveform)");
			query.bindValue(":timestamp", spike->timestamp + clockoffset);
			query.bindValue(":channel", spike->channel);
			query.bindValue(":unit", spike->unit);
			query.bindValue(":waveform", waveformStr);
			query.exec();

			spike++;
		}

		trial++;
	}
	neuralDB.commit();
	outputStream.flush();

}

void genBehavData()
{
	outputStream<<"Generating behavioral data\n";
	outputStream.flush();

	//Since this data is generated by Picto, we're going to make two assumpitions:
	//   1. There is no jitter.  While this may not be true, we'll use the Picto
	//      timebase as "true" time.
	//   2. Time starts at 0.0.

	QSqlQuery query(beahvioralDB);
	//kill the tables left over from a previous run
	query.exec("DROP TABLE alignment");
	query.exec("DROP TABLE events");
	query.exec("DROP TABLE eyetracker");

	//Set up the tables
	query.exec("CREATE TABLE alignment (id INTEGER PRIMARY KEY, timestamp REAL, aligncode INTEGER)");
	query.exec("CREATE TABLE events (id INTEGER PRIMARY KEY, timestamp REAL, eventcode INTEGER)");
	query.exec("CREATE TABLE eyetracker (id INTEGER PRIMARY KEY, timestamp REAL, xCoord INTEGER, yCoord INTEGER)");

	beahvioralDB.transaction();

	//Generate the alignment codes.
	QList<TrialStruct>::iterator trial = experiment.begin();
	while(trial != experiment.end())
	{
		query.prepare("INSERT INTO alignment (timestamp,aligncode) "
			"VALUES(:timestamp, :aligncode)");
		query.bindValue(":timestamp", trial->trialStart);
		query.bindValue(":aligncode", trial->trialNum);
		query.exec();

		query.prepare("INSERT INTO alignment (timestamp,aligncode) "
			"VALUES(:timestamp, :aligncode)");
		query.bindValue(":timestamp", trial->trialEnd);
		query.bindValue(":aligncode", trial->trialNum);
		query.exec();

		trial++;
	}

	//generate the event codes
	trial = experiment.begin();
	while(trial != experiment.end())
	{
		QList<EventStruct>::iterator trialEvent = trial->events.begin();
		while(trialEvent != trial->events.end())
		{
			query.prepare("INSERT INTO events (timestamp,eventcode) VALUES(:timestamp, :eventcode)");
			query.bindValue(":timestamp", trialEvent->timestamp);
			query.bindValue(":eventcode", trialEvent->eventCode);
			query.exec();

			trialEvent++;
		}

		trial++;
	}

	//generate the eyetracker data
	//The eyetracker is running continuously, so we'll simply generate a 
	//bunch of random values at a constant rate
	double time;
	int x=320, y=240;
	for(time=0; time<experiment.last().trialEnd; time += 0.01)
	{
		x += rand()%5 - 2;
		y += rand()%5 - 2;

		query.prepare("INSERT INTO eyetracker (timestamp,xCoord,yCoord) "
			"VALUES (:timestamp, :xCoord, :yCoord)");
		query.bindValue(":timestamp", time);
		query.bindValue(":xCoord", x);
		query.bindValue(":yCoord", y);
		query.exec();
	}

	beahvioralDB.commit();

	outputStream.flush();
}

//generates a random value from a normal distribution
double normal(const double &mean, const double &std)
{
  static const double pii=3.1415927;
  static const double r_max=RAND_MAX+1;
  return std*sqrt(-2*log((rand()+1)/r_max))*sin(2*pii*rand()/r_max)+mean;
} 