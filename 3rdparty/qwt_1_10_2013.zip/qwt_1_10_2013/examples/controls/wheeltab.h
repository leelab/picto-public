#ifndef _WHEEL_TAB_H
#define _WHEEL_TAB_H 1

#include <qwidget.h>

class WheelTab: public QWidget
{
public:
    WheelTab( QWidget *parent = NULL );
};

#endif
