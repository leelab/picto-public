$Id: README.txt 633561 2008-03-04 17:39:08Z jeremias $

This directory contains a poster on Apache FOP. It was initially 
created for OpenExpo '06 (http://www.openexpo.ch).

To create the PDF just call go.bat.

The fully reconstruct the PDF you need some fonts installed in
your operating system: Verdana and Lucida Console which are
available in every Windows installation.

You will also need English hyphenation patterns.